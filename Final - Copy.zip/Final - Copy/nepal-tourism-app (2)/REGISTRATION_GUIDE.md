# Tours Nepal - User Registration Guide

## New User Registration

Tours Nepal now supports user registration for both tourists and guides. Users can create their own accounts without admin intervention.

### Tourist Registration

**Access:** Click "Register as Tourist" on the login screen

**Required Information:**
- Full Name
- Nationality (dropdown with common countries)
- Contact Number
- Emergency Contact
- Username (must be unique)
- Password (minimum 6 characters)
- Confirm Password

**Optional Information:**
- Email Address

**Process:**
1. Fill in all required fields
2. Select nationality from dropdown (or type custom)
3. Create unique username and secure password
4. Accept Terms and Conditions
5. Click "Register as Tourist"
6. Receive confirmation with Tourist ID
7. Login immediately with new credentials

### Guide Registration

**Access:** Click "Register as Guide" on the login screen

**Required Information:**
- Full Name
- Contact Number
- Experience Level (dropdown selection)
- Languages Spoken (checkbox selection)
- Username (must be unique)
- Password (minimum 6 characters)
- Confirm Password

**Optional Information:**
- Email Address
- Specializations (text area for detailed description)
- Guide License Number

**Language Options:**
- Nepali ✓ (default selected)
- English ✓ (default selected)
- Hindi
- Chinese
- French
- German
- Japanese
- Korean

**Experience Levels:**
- Less than 1 year
- 1-2 years
- 3-5 years
- 6-10 years
- 11-15 years
- More than 15 years

**Process:**
1. Fill in all required fields
2. Select experience level
3. Choose languages (minimum 1 required)
4. Add specializations and license if applicable
5. Create unique username and secure password
6. Accept Terms and Conditions
7. Certify information accuracy
8. Click "Register as Guide"
9. Receive confirmation with Guide ID
10. Login immediately with new credentials

## Validation Features

### Username Validation
- Must be unique across all users (tourists, guides, admin)
- Cannot use "admin" as username
- Real-time checking during registration

### Password Security
- Minimum 6 characters required
- Must match confirmation field
- Stored securely in system

### Data Integrity
- All required fields must be filled
- Email format validation (if provided)
- Contact number format checking
- Terms acceptance mandatory

## Post-Registration

### Immediate Access
- New users can login immediately after registration
- No admin approval required for basic access
- All standard features available instantly

### Data Storage
- Registration data automatically saved to text files
- Real-time synchronization with admin dashboard
- Backup and recovery supported

### Account Management
- Users can update their information through admin
- Password changes supported
- Account deactivation available

## Admin Visibility

### Real-time Updates
- New registrations appear immediately in admin dashboard
- Registration statistics updated automatically
- User management tools available

### Registration Monitoring
- Admin can view all registered users
- Registration timestamps tracked
- User activity monitoring

## Security Features

### Data Protection
- Passwords stored securely
- Personal information protected
- Emergency contact privacy maintained

### Fraud Prevention
- Duplicate username prevention
- Email validation (when provided)
- Terms acceptance tracking

## Troubleshooting

### Common Issues
1. **Username Already Exists**
   - Try different username
   - Check for typos in existing username

2. **Password Mismatch**
   - Ensure both password fields match exactly
   - Check caps lock status

3. **Missing Required Fields**
   - All required fields must be completed
   - Check for empty dropdown selections

4. **Terms Not Accepted**
   - Must check Terms and Conditions checkbox
   - Must check information accuracy (guides only)

### Support
- Contact admin for account issues
- Check data files for registration records
- Review console logs for technical errors

---

**Welcome to Tours Nepal!** 🏔️
*Discover the beauty of Nepal with trusted local guides*
