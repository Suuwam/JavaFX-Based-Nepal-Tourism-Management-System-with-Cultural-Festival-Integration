# Nepal Tourism Management System

A comprehensive JavaFX-based tourism management application designed specifically for Nepal's tourism industry.

## Features

### Multi-User Authentication System
- **Admin Dashboard**: Complete CRUD operations for tourists, guides, attractions, and bookings
- **Tourist Portal**: Book tours, manage bookings, report emergencies
- **Guide Interface**: View and manage assigned bookings

### Core Functionality
- **CRUD Operations**: Full Create, Read, Update, Delete functionality for all entities
- **Data Persistence**: All data saved to text files for permanent storage
- **Emergency Reporting**: Real-time emergency reporting system with timestamps
- **Multilingual Support**: English and Nepali language support
- **Data Analytics**: Charts and statistics for business insights

### Nepal-Specific Features
- **Local Attractions**: Pre-loaded with popular Nepal destinations (Everest Base Camp, Annapurna Circuit, etc.)
- **Cultural Context**: Designed with Nepal's tourism industry in mind
- **Festival Integration**: Framework for seasonal and festival-based features

## Technology Stack

- **Frontend**: JavaFX 17
- **Language**: Java 11+
- **Build Tool**: Maven
- **Data Storage**: File-based persistence
- **Charts**: JavaFX Charts (PieChart, BarChart)
- **Styling**: CSS for modern UI design

## Getting Started

### Prerequisites
- Java 11 or higher
- Maven 3.6+
- JavaFX 17 (included in dependencies)

### Installation

1. Clone the repository:
\`\`\`bash
git clone <repository-url>
cd nepal-tourism-app
\`\`\`

2. Build the project:
\`\`\`bash
mvn clean compile
\`\`\`

3. Run the application:
\`\`\`bash
mvn javafx:run
\`\`\`

### Default Login Credentials

**Admin:**
- Username: `admin`
- Password: `admin`

**Sample Tourist:**
- Username: `john`
- Password: `password`

**Sample Guide:**
- Username: `ram`
- Password: `password`

## Project Structure

\`\`\`
src/
├── main/
│   ├── java/
│   │   └── com/nepal/tourism/
│   │       ├── TourismApp.java              # Main application class
│   │       ├── models/                      # Data models
│   │       │   ├── Tourist.java
│   │       │   ├── Guide.java
│   │       │   ├── Attraction.java
│   │       │   ├── Booking.java
│   │       │   └── EmergencyReport.java
│   │       ├── controllers/                 # UI controllers
│   │       │   ├── LoginController.java
│   │       │   ├── AdminController.java
│   │       │   ├── TouristController.java
│   │       │   └── GuideController.java
│   │       └── utils/                       # Utility classes
│   │           ├── DataManager.java
│   │           └── LanguageManager.java
│   └── resources/
│       └── styles.css                       # Application styling
└── pom.xml                                  # Maven configuration
\`\`\`

## Key Features Explained

### Data Management
- **In-Memory Storage**: Uses Java Collections (HashMap, ArrayList) for fast data access
- **File Persistence**: Automatic save/load functionality using Java serialization
- **Data Integrity**: Proper ID generation and relationship management

### User Interfaces

#### Admin Dashboard
- Complete system overview with statistics
- CRUD operations for all entities
- Emergency reports monitoring
- Data visualization with charts

#### Tourist Portal
- Personal booking management
- Attraction browsing
- Emergency reporting system
- Booking creation interface

#### Guide Interface
- View assigned bookings
- Cancel bookings when necessary
- Profile management

### Multilingual Support
- Dynamic language switching
- Support for English and Nepali
- Extensible translation system

### Emergency System
- One-click emergency reporting
- Timestamp logging
- Admin notification system
- Booking-specific incident tracking

## Data Models

### Tourist
- Personal information (name, nationality, contact)
- Emergency contact details
- Authentication credentials

### Guide
- Professional details (experience, languages)
- Contact information
- Authentication credentials

### Attraction
- Nepal-specific destinations
- Difficulty ratings
- Location and type classification

### Booking
- Tourist-Guide-Attraction relationships
- Date and status tracking
- Complete booking lifecycle management

### Emergency Report
- Incident documentation
- Timestamp and reporter tracking
- Booking association

## Customization

### Adding New Languages
1. Extend `LanguageManager.java`
2. Add translation mappings
3. Update UI language selector

### Adding New Attraction Types
1. Update attraction type options in forms
2. Modify data validation if needed
3. Update charts and statistics

### Styling Customization
- Modify `styles.css` for visual changes
- Nepal-themed color scheme included
- Responsive design considerations

## Building for Distribution

Create an executable JAR:
\`\`\`bash
mvn clean package
\`\`\`

The shaded JAR will be created in the `target/` directory.

## Future Enhancements

- Database integration (MySQL/PostgreSQL)
- Web-based interface
- Mobile application
- Payment processing integration
- Advanced reporting features
- Real-time notifications
- GPS tracking for emergency situations

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support and questions, please create an issue in the repository or contact the development team.

---

**Namaste! Welcome to Nepal Tourism Management System** 🏔️
