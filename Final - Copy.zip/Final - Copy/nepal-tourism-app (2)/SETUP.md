# Nepal Tourism Management System - Setup Guide

## Prerequisites

Before running the application, ensure you have the following installed:

### 1. Java Development Kit (JDK) 11 or higher
- Download from: https://adoptium.net/
- Verify installation: `java -version`

### 2. Apache Maven 3.6+
- Download from: https://maven.apache.org/download.cgi
- Verify installation: `mvn -version`

## Quick Start

### Windows Users:
1. Double-click `run.bat`
2. The script will automatically compile and run the application

### Linux/Mac Users:
1. Make the script executable: `chmod +x run.sh`
2. Run the script: `./run.sh`

### Manual Setup:
\`\`\`bash
# Clone or extract the project
cd nepal-tourism-app

# Compile the project
mvn clean compile

# Run the application
mvn javafx:run
\`\`\`

## Default Login Credentials

### Admin Dashboard:
- **Username:** `admin`
- **Password:** `admin`

### Sample Tourist Account:
- **Username:** `john`
- **Password:** `password`

### Sample Guide Account:
- **Username:** `ram`
- **Password:** `password`

## Data Storage

The application automatically creates a `data/` folder in the project directory to store:
- `tourists.txt` - Tourist information
- `guides.txt` - Guide information  
- `attractions.txt` - Attraction details
- `bookings.txt` - Booking records
- `emergency_reports.txt` - Emergency incident reports

All data is automatically saved when:
- Any CRUD operation is performed
- The application is closed
- Manual save is triggered from the admin menu

## Features Overview

### Real-time Data Synchronization
- All changes are immediately reflected across all user interfaces
- Tourist creates booking → Admin sees it instantly
- Admin updates attraction → Tourist sees updated info
- Guide cancels booking → Tourist is notified

### Multi-language Support
- Switch between English and Nepali (नेपाली)
- Language preference is maintained across sessions

### Emergency Reporting System
- Tourists can report emergencies for their bookings
- Reports are timestamped and logged
- Admin can view all emergency reports

### Data Analytics
- Tourist nationality distribution (Pie Chart)
- Popular attractions analysis (Bar Chart)
- Real-time statistics dashboard

## Troubleshooting

### JavaFX Runtime Error:
If you get "JavaFX runtime components are missing":
1. Ensure you're using the Maven command: `mvn javafx:run`
2. Don't try to run the JAR directly
3. JavaFX modules are handled by the Maven plugin

### Data Not Persisting:
- Check if `data/` folder has write permissions
- Ensure application closes properly (don't force-kill)
- Check console for file I/O error messages

### UI Not Updating:
- The application uses real-time data synchronization
- If changes aren't reflected, check console for errors
- Try refreshing by switching tabs or restarting

### Performance Issues:
- The application is designed for moderate data loads
- Large datasets may require optimization
- Consider database integration for production use

## Development Notes

### Project Structure:
\`\`\`
src/main/java/com/nepal/tourism/
├── TourismApp.java              # Main application entry point
├── models/                      # Data models (Tourist, Guide, etc.)
├── controllers/                 # UI controllers for each user type
├── utils/                       # Utility classes (DataManager, LanguageManager)
└── module-info.java            # Java module configuration
\`\`\`

### Key Features:
- **Observer Pattern**: Real-time UI updates via DataChangeListener
- **File I/O**: Text-based persistence with structured format
- **Thread Safety**: ConcurrentHashMap and CopyOnWriteArrayList
- **Validation**: Form validation and error handling
- **Internationalization**: Multi-language support framework

## Support

For issues or questions:
1. Check the console output for error messages
2. Verify all prerequisites are installed correctly
3. Ensure proper file permissions for data directory
4. Review the troubleshooting section above

---

**स्वागतम्! Welcome to Nepal Tourism Management System!** 🏔️
