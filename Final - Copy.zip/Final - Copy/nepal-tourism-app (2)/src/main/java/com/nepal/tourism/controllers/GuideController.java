package com.nepal.tourism.controllers;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import com.nepal.tourism.models.*;
import com.nepal.tourism.utils.DataManager;
import com.nepal.tourism.utils.LanguageManager;

import java.time.LocalDate;
import java.util.List;

public class GuideController implements DataManager.DataChangeListener {
    private Stage primaryStage;
    private Guide currentGuide;
    private LanguageManager langManager = LanguageManager.getInstance();
    private DataManager dataManager = DataManager.getInstance();
    
    // Observable lists for real-time updates
    private ObservableList<BookingDisplay> myBookingsList = FXCollections.observableArrayList();
    
    public GuideController(Guide guide) {
        this.currentGuide = guide;
    }
    
    public void showGuideDashboard(Stage stage) {
        this.primaryStage = stage;
        
        // Register for data change notifications
        dataManager.addDataChangeListener(this);
        
        BorderPane root = new BorderPane();
        root.getStyleClass().add("guide-dashboard");
        
        // Top menu bar
        MenuBar menuBar = createMenuBar();
        root.setTop(menuBar);
        
        // Main content with tabs
        TabPane tabPane = new TabPane();
        tabPane.getTabs().addAll(
            createMyBookingsTab(),
            createProfileTab()
        );
        
        root.setCenter(tabPane);
        
        // Load initial data
        refreshMyBookings();
        
        Scene scene = new Scene(root, 1200, 800);
        scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());
        
        primaryStage.setTitle("Tours Nepal - Guide Dashboard");
        primaryStage.setScene(scene);
        primaryStage.setOnCloseRequest(e -> {
            dataManager.removeDataChangeListener(this);
            dataManager.saveDataToFile();
        });
        primaryStage.show();
    }
    
    @Override
    public void onDataChanged(String dataType, String operation, Object data) {
        // Update UI on JavaFX Application Thread
        Platform.runLater(() -> {
            System.out.println("Guide Dashboard: Data changed - " + dataType + " " + operation);
            if ("BOOKING".equals(dataType) || "TOURIST".equals(dataType) || "ATTRACTION".equals(dataType)) {
                refreshMyBookings();
            }
        });
    }
    
    private void refreshMyBookings() {
        myBookingsList.clear();
        List<Booking> bookings = dataManager.getBookingsByGuide(currentGuide.getId());
        
        for (Booking booking : bookings) {
            Tourist tourist = dataManager.getTourist(booking.getTouristId());
            Attraction attraction = dataManager.getAttraction(booking.getAttractionId());
            
            myBookingsList.add(new BookingDisplay(
                booking.getId(),
                tourist != null ? tourist.getName() : "Unknown",
                currentGuide.getName(),
                attraction != null ? attraction.getName() : "Unknown",
                booking.getDate(),
                booking.getStatus()
            ));
        }
    }
    
    private MenuBar createMenuBar() {
        MenuBar menuBar = new MenuBar();
        
        Menu fileMenu = new Menu("File");
        MenuItem logoutItem = new MenuItem(langManager.getText("logout"));
        logoutItem.setOnAction(e -> {
            dataManager.removeDataChangeListener(this);
            dataManager.saveDataToFile();
            LoginController loginController = new LoginController();
            loginController.showLoginScreen(primaryStage);
        });
        fileMenu.getItems().add(logoutItem);
        
        Menu languageMenu = new Menu(langManager.getText("language"));
        MenuItem englishItem = new MenuItem("English");
        MenuItem nepaliItem = new MenuItem("नेपाली");
        
        englishItem.setOnAction(e -> {
            langManager.setLanguage("en");
            showGuideDashboard(primaryStage);
        });
        
        nepaliItem.setOnAction(e -> {
            langManager.setLanguage("ne");
            showGuideDashboard(primaryStage);
        });
        
        languageMenu.getItems().addAll(englishItem, nepaliItem);
        menuBar.getMenus().addAll(fileMenu, languageMenu);
        
        return menuBar;
    }
    
    private Tab createMyBookingsTab() {
        Tab tab = new Tab(langManager.getText("my_bookings"));
        tab.setClosable(false);
        
        VBox content = new VBox(10);
        content.setPadding(new Insets(20));
        
        // Buttons
        HBox buttonBox = new HBox(10);
        Button cancelButton = new Button("Cancel Booking");
        Button updateStatusButton = new Button("Update Status");
        
        cancelButton.getStyleClass().add("danger-button");
        updateStatusButton.getStyleClass().add("secondary-button");
        
        buttonBox.getChildren().addAll(cancelButton, updateStatusButton);
        
        // Table
        TableView<BookingDisplay> table = new TableView<>();
        table.setItems(myBookingsList);
        table.getColumns().addAll(
            createTableColumn("ID", "id"),
            createTableColumn("Tourist", "touristName"),
            createTableColumn("Attraction", "attractionName"),
            createTableColumn(langManager.getText("date"), "date"),
            createTableColumn(langManager.getText("status"), "status")
        );
        
        // Button actions
        cancelButton.setOnAction(e -> {
            BookingDisplay selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
                confirmation.setTitle("Confirm Cancellation");
                confirmation.setHeaderText("Cancel Booking");
                confirmation.setContentText("Are you sure you want to cancel this booking?");
                
                if (confirmation.showAndWait().get() == ButtonType.OK) {
                    Booking booking = dataManager.getBooking(selected.getId());
                    if (booking != null) {
                        booking.setStatus("Cancelled");
                        dataManager.updateBooking(booking);
                        showAlert(Alert.AlertType.INFORMATION, "Success", "Booking cancelled successfully!");
                    }
                }
            } else {
                showAlert(Alert.AlertType.WARNING, "Warning", "Please select a booking to cancel.");
            }
        });
        
        updateStatusButton.setOnAction(e -> {
            BookingDisplay selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                showUpdateStatusDialog(selected.getId());
            } else {
                showAlert(Alert.AlertType.WARNING, "Warning", "Please select a booking to update status.");
            }
        });
        
        content.getChildren().addAll(buttonBox, table);
        tab.setContent(content);
        
        return tab;
    }
    
    private Tab createProfileTab() {
        Tab tab = new Tab("Profile");
        tab.setClosable(false);
        
        VBox content = new VBox(20);
        content.setPadding(new Insets(20));
        
        // Profile information
        GridPane profileGrid = new GridPane();
        profileGrid.setHgap(10);
        profileGrid.setVgap(10);
        profileGrid.getStyleClass().add("profile-grid");
        
        profileGrid.add(new Label(langManager.getText("name") + ":"), 0, 0);
        profileGrid.add(new Label(currentGuide.getName()), 1, 0);
        
        profileGrid.add(new Label(langManager.getText("languages") + ":"), 0, 1);
        profileGrid.add(new Label(String.join(", ", currentGuide.getLanguages())), 1, 1);
        
        profileGrid.add(new Label(langManager.getText("experience") + ":"), 0, 2);
        profileGrid.add(new Label(currentGuide.getExperience() + " years"), 1, 2);
        
        profileGrid.add(new Label(langManager.getText("contact") + ":"), 0, 3);
        profileGrid.add(new Label(currentGuide.getContact()), 1, 3);
        
        // Statistics
        Label statsTitle = new Label("My Statistics");
        statsTitle.getStyleClass().add("section-title");
        
        GridPane statsGrid = new GridPane();
        statsGrid.setHgap(10);
        statsGrid.setVgap(10);
        statsGrid.getStyleClass().add("profile-grid");
        
        long totalBookings = dataManager.getBookingsByGuide(currentGuide.getId()).size();
        long confirmedBookings = dataManager.getBookingsByGuide(currentGuide.getId()).stream()
                .filter(b -> "Confirmed".equals(b.getStatus())).count();
        long completedBookings = dataManager.getBookingsByGuide(currentGuide.getId()).stream()
                .filter(b -> "Completed".equals(b.getStatus())).count();
        
        statsGrid.add(new Label("Total Bookings:"), 0, 0);
        statsGrid.add(new Label(String.valueOf(totalBookings)), 1, 0);
        
        statsGrid.add(new Label("Confirmed Bookings:"), 0, 1);
        statsGrid.add(new Label(String.valueOf(confirmedBookings)), 1, 1);
        
        statsGrid.add(new Label("Completed Bookings:"), 0, 2);
        statsGrid.add(new Label(String.valueOf(completedBookings)), 1, 2);
        
        content.getChildren().addAll(profileGrid, statsTitle, statsGrid);
        tab.setContent(content);
        
        return tab;
    }
    
    private void showUpdateStatusDialog(String bookingId) {
        Stage dialog = new Stage();
        dialog.setTitle("Update Booking Status");
        
        VBox content = new VBox(10);
        content.setPadding(new Insets(20));
        
        Label titleLabel = new Label("Update Status for Booking: " + bookingId);
        titleLabel.getStyleClass().add("section-title");
        
        ComboBox<String> statusCombo = new ComboBox<>();
        statusCombo.getItems().addAll("Pending", "Confirmed", "In Progress", "Completed", "Cancelled");
        
        Booking booking = dataManager.getBooking(bookingId);
        if (booking != null) {
            statusCombo.setValue(booking.getStatus());
        }
        
        HBox buttonBox = new HBox(10);
        Button updateButton = new Button("Update");
        Button cancelButton = new Button("Cancel");
        
        updateButton.getStyleClass().add("primary-button");
        
        updateButton.setOnAction(e -> {
            if (statusCombo.getValue() != null && booking != null) {
                booking.setStatus(statusCombo.getValue());
                dataManager.updateBooking(booking);
                
                showAlert(Alert.AlertType.INFORMATION, "Success", 
                         "Booking status updated to: " + statusCombo.getValue());
                
                dialog.close();
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Please select a status.");
            }
        });
        
        cancelButton.setOnAction(e -> dialog.close());
        
        buttonBox.getChildren().addAll(updateButton, cancelButton);
        
        content.getChildren().addAll(titleLabel, new Label("New Status:"), statusCombo, buttonBox);
        
        Scene scene = new Scene(content, 1200, 800);
        scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());
        dialog.setScene(scene);
        dialog.showAndWait();
    }
    
    private <T> TableColumn<T, String> createTableColumn(String title, String property) {
        TableColumn<T, String> column = new TableColumn<>(title);
        column.setCellValueFactory(new PropertyValueFactory<>(property));
        column.setPrefWidth(150);
        return column;
    }
    
    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    
    // Helper class for booking display
    public static class BookingDisplay {
        private String id;
        private String touristName;
        private String guideName;
        private String attractionName;
        private LocalDate date;
        private String status;
        
        public BookingDisplay(String id, String touristName, String guideName, 
                            String attractionName, LocalDate date, String status) {
            this.id = id;
            this.touristName = touristName;
            this.guideName = guideName;
            this.attractionName = attractionName;
            this.date = date;
            this.status = status;
        }
        
        // Getters
        public String getId() { return id; }
        public String getTouristName() { return touristName; }
        public String getGuideName() { return guideName; }
        public String getAttractionName() { return attractionName; }
        public LocalDate getDate() { return date; }
        public String getStatus() { return status; }
    }
}
