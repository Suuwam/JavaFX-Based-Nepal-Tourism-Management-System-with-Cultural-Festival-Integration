package com.nepal.tourism.controllers;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import com.nepal.tourism.models.*;
import com.nepal.tourism.utils.DataManager;
import com.nepal.tourism.utils.LanguageManager;
// --- ADD THESE IMPORTS FOR IMAGE HANDLING ---
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import java.io.InputStream;
// --- END ADDITIONS ---

public class LoginController {
    private Stage primaryStage;
    private LanguageManager langManager = LanguageManager.getInstance();
    private DataManager dataManager = DataManager.getInstance();

    public void showLoginScreen(Stage stage) {
        this.primaryStage = stage;

        VBox root = new VBox(20);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(50));
        root.getStyleClass().add("login-container");

        // --- REPLACE THE TITLE LABEL WITH LOGO ---
        // Title (now an ImageView)
        ImageView logoImageView = new ImageView(); // Create ImageView
        // Attempt to load the image
        try {
            // Use getResourceAsStream for better resource handling
            InputStream imageStream = getClass().getResourceAsStream("/images/logo.png");
            if (imageStream != null) {
                Image logoImage = new Image(imageStream);
                logoImageView.setImage(logoImage);
                // Set desired dimensions for the logo (adjust as needed)
                logoImageView.setFitWidth(200); // Set width
                logoImageView.setFitHeight(150); // Set height
                logoImageView.setPreserveRatio(true); // Maintain aspect ratio
                logoImageView.setSmooth(true); // Smoother scaling
            } else {
                System.err.println("Could not find logo image: /images/logo.png");
                // Fallback to text label if image not found
                Label fallbackLabel = new Label("Tour Nepal - Tourism Management System");
                fallbackLabel.getStyleClass().add("title");
                root.getChildren().add(fallbackLabel);
            }
        } catch (Exception e) {
            System.err.println("Error loading logo image: " + e.getMessage());
            e.printStackTrace();
            // Fallback to text label if image loading fails
            Label fallbackLabel = new Label("Tours Nepal - Tourism Management System");
            fallbackLabel.getStyleClass().add("title");
            root.getChildren().add(fallbackLabel);
        }
        // Only add the ImageView if it was successfully configured (i.e., image loaded or we want to show a placeholder/broken image icon)
        // The logic above adds a fallback label instead, so we don't add the ImageView to root if image fails.
        // If you prefer to always add the ImageView (even if broken, showing default icon), uncomment the next line and remove the conditional logic above.
        // root.getChildren().add(logoImageView);

        // --- ADD THE LOGO TO THE ROOT IF LOADED SUCCESSFULLY ---
        // We need to check if the ImageView actually has an image set.
        // A simple way is to check if we added the fallback label. If not, we add the ImageView.
        // Let's restructure this slightly for clarity.
        boolean logoAdded = false;
        try {
            InputStream imageStream = getClass().getResourceAsStream("/images/logo.png");
            if (imageStream != null) {
                Image logoImage = new Image(imageStream);
                logoImageView.setImage(logoImage);
                logoImageView.setFitWidth(200);
                logoImageView.setFitHeight(150);
                logoImageView.setPreserveRatio(true);
                logoImageView.setSmooth(true);
                root.getChildren().add(logoImageView); // Add ImageView to root
                logoAdded = true;
            }
        } catch (Exception e) {
            System.err.println("Error loading logo image: " + e.getMessage());
            e.printStackTrace();
        }

        // If logo wasn't added successfully, add the text label as fallback
        if (!logoAdded) {
            Label titleLabel = new Label("Tours Nepal - Tourism Management System");
            titleLabel.getStyleClass().add("title");
            root.getChildren().add(titleLabel); // Add fallback label
        }
        // --- END LOGO REPLACEMENT ---

        // Optional: Add a subtitle label below the logo if desired
        // Label subtitleLabel = new Label("Explore the Himalayas");
        // subtitleLabel.getStyleClass().add("subtitle");
        // root.getChildren().add(subtitleLabel);

        // Language selector
        HBox languageBox = new HBox(10);
        languageBox.setAlignment(Pos.CENTER);
        Label langLabel = new Label(langManager.getText("language") + ":");
        ComboBox<String> languageCombo = new ComboBox<>();
        languageCombo.getItems().addAll("English", "नेपाली");
        languageCombo.setValue("English");
        languageCombo.setOnAction(e -> {
            String selected = languageCombo.getValue();
            if (selected.equals("नेपाली")) {
                langManager.setLanguage("ne");
            } else {
                langManager.setLanguage("en");
            }
            showLoginScreen(stage); // Refresh the screen
        });
        languageBox.getChildren().addAll(langLabel, languageCombo);

        // Login form
        GridPane loginForm = new GridPane();
        loginForm.setAlignment(Pos.CENTER);
        loginForm.setHgap(10);
        loginForm.setVgap(10);
        loginForm.getStyleClass().add("login-form");

        Label usernameLabel = new Label(langManager.getText("username") + ":");
        TextField usernameField = new TextField();
        usernameField.setPromptText(langManager.getText("username"));

        Label passwordLabel = new Label(langManager.getText("password") + ":");
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText(langManager.getText("password"));

        Label userTypeLabel = new Label("User Type:");
        ComboBox<String> userTypeCombo = new ComboBox<>();
        userTypeCombo.getItems().addAll(
                langManager.getText("admin"),
                langManager.getText("tourist"),
                langManager.getText("guide")
        );
        userTypeCombo.setValue(langManager.getText("tourist"));

        Button loginButton = new Button(langManager.getText("login"));
        loginButton.getStyleClass().add("primary-button");
        loginButton.setOnAction(e -> handleLogin(usernameField.getText(),
                passwordField.getText(),
                userTypeCombo.getValue()));

        loginForm.add(usernameLabel, 0, 0);
        loginForm.add(usernameField, 1, 0);
        loginForm.add(passwordLabel, 0, 1);
        loginForm.add(passwordField, 1, 1);
        loginForm.add(userTypeLabel, 0, 2);
        loginForm.add(userTypeCombo, 1, 2);
        loginForm.add(loginButton, 1, 3);

        // Registration section
        VBox registrationSection = new VBox(10);
        registrationSection.setAlignment(Pos.CENTER);

        Label registrationLabel = new Label("Don't have an account?");
        registrationLabel.getStyleClass().add("registration-label");

        HBox registrationButtons = new HBox(10);
        registrationButtons.setAlignment(Pos.CENTER);

        Button registerTouristButton = new Button("Register as Tourist");
        Button registerGuideButton = new Button("Register as Guide");

        registerTouristButton.getStyleClass().add("registration-button");
        registerGuideButton.getStyleClass().add("registration-button");

        registerTouristButton.setOnAction(e -> {
            RegistrationController registrationController = new RegistrationController();
            registrationController.showRegistrationScreen(stage, "Tourist");
        });

        registerGuideButton.setOnAction(e -> {
            RegistrationController registrationController = new RegistrationController();
            registrationController.showRegistrationScreen(stage, "Guide");
        });

        registrationButtons.getChildren().addAll(registerTouristButton, registerGuideButton);
        registrationSection.getChildren().addAll(registrationLabel, registrationButtons);

        // Add registration section to root
        root.getChildren().addAll(languageBox, loginForm, registrationSection); // Removed titleLabel from here

        Scene scene = new Scene(root, 1200, 800);
        scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());

        primaryStage.setTitle("Tours Nepal - Login");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void handleLogin(String username, String password, String userType) {
        if (username.isEmpty() || password.isEmpty()) {
            showAlert("Error", "Please enter username and password");
            return;
        }

        if (userType.equals(langManager.getText("admin")) || userType.equals("Admin")) {
            if (dataManager.authenticateAdmin(username, password)) {
                AdminController adminController = new AdminController();
                adminController.showAdminDashboard(primaryStage);
            } else {
                showAlert("Error", "Invalid admin credentials");
            }
        } else if (userType.equals(langManager.getText("tourist")) || userType.equals("Tourist")) {
            Tourist tourist = dataManager.authenticateTourist(username, password);
            if (tourist != null) {
                TouristController touristController = new TouristController(tourist);
                touristController.showTouristDashboard(primaryStage);
            } else {
                showAlert("Error", "Invalid tourist credentials");
            }
        } else if (userType.equals(langManager.getText("guide")) || userType.equals("Guide")) {
            Guide guide = dataManager.authenticateGuide(username, password);
            if (guide != null) {
                GuideController guideController = new GuideController(guide);
                guideController.showGuideDashboard(primaryStage);
            } else {
                showAlert("Error", "Invalid guide credentials");
            }
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}