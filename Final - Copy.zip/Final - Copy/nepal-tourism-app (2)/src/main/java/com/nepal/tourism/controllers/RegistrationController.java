package com.nepal.tourism.controllers;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import com.nepal.tourism.models.*;
import com.nepal.tourism.utils.DataManager;
import com.nepal.tourism.utils.LanguageManager;

import java.util.Arrays;
import java.util.List;

public class RegistrationController {
    private Stage primaryStage;
    private LanguageManager langManager = LanguageManager.getInstance();
    private DataManager dataManager = DataManager.getInstance();

    public void showRegistrationScreen(Stage stage, String userType) {
        this.primaryStage = stage;

        VBox root = new VBox(20);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(30));
        root.getStyleClass().add("registration-container");


        // --- Logo Image ---
        javafx.scene.image.ImageView logoImageView = new javafx.scene.image.ImageView();
        boolean logoLoaded = false;
        try {
            java.io.InputStream imageStream = getClass().getResourceAsStream("/images/logo.png");
            if (imageStream != null) {
                javafx.scene.image.Image logoImage = new javafx.scene.image.Image(imageStream);
                logoImageView.setImage(logoImage);
                logoImageView.setFitWidth(200); // Adjust width as needed
                logoImageView.setFitHeight(150); // Adjust height as needed
                logoImageView.setPreserveRatio(true);
                logoImageView.setSmooth(true);
                logoLoaded = true;
            }
        } catch (Exception e) {
            System.err.println("Error loading logo image: " + e.getMessage());
            e.printStackTrace();
        }
        // --- End Logo Image ---

        Label subtitleLabel = new Label("Register as " + userType);
        subtitleLabel.getStyleClass().add("subtitle");

        // Registration form
        ScrollPane scrollPane = new ScrollPane();
        VBox formContainer = new VBox(15);
        formContainer.setAlignment(Pos.CENTER);
        formContainer.setPadding(new Insets(20));
        formContainer.getStyleClass().add("registration-form");

        if ("Tourist".equals(userType)) {
            formContainer.getChildren().add(createTouristRegistrationForm());
        } else if ("Guide".equals(userType)) {
            formContainer.getChildren().add(createGuideRegistrationForm());
        }

        scrollPane.setContent(formContainer);
        scrollPane.setFitToWidth(true);
        scrollPane.setPrefHeight(500);

        // Back button
        Button backButton = new Button("Back to Login");
        backButton.getStyleClass().add("secondary-button");
        backButton.setOnAction(e -> {
            LoginController loginController = new LoginController();
            loginController.showLoginScreen(primaryStage);
        });

        // Add logo or fallback title, then other elements
        if (logoLoaded) {
            root.getChildren().addAll(logoImageView, subtitleLabel, scrollPane, backButton);
        } else {
            // Fallback to text title if image fails to load
            Label titleLabel = new Label("Tours Nepal - Registration");
            titleLabel.getStyleClass().add("title");
            root.getChildren().addAll(titleLabel, subtitleLabel, scrollPane, backButton);
        }

        Scene scene = new Scene(root, 1200, 800);
        scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());

        primaryStage.setTitle("Tours Nepal - Registration");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private VBox createTouristRegistrationForm() {
        VBox form = new VBox(15);
        form.setAlignment(Pos.CENTER);

        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(15);
        grid.setVgap(15);

        // Form fields
        TextField nameField = new TextField();
        nameField.setPromptText("Full Name");

        ComboBox<String> nationalityCombo = new ComboBox<>();
        nationalityCombo.getItems().addAll(
            "Nepal", "India", "China", "USA", "UK", "Germany", "France",
            "Japan", "Australia", "Canada", "South Korea", "Thailand",
            "Singapore", "Malaysia", "Other"
        );
        nationalityCombo.setPromptText("Select Nationality");
        nationalityCombo.setEditable(true);

        TextField contactField = new TextField();
        contactField.setPromptText("Contact Number");

        TextField emergencyContactField = new TextField();
        emergencyContactField.setPromptText("Emergency Contact");

        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");

        PasswordField confirmPasswordField = new PasswordField();
        confirmPasswordField.setPromptText("Confirm Password");

        TextField emailField = new TextField();
        emailField.setPromptText("Email Address (Optional)");

        // Add fields to grid
        grid.add(new Label("Full Name:"), 0, 0);
        grid.add(nameField, 1, 0);

        grid.add(new Label("Nationality:"), 0, 1);
        grid.add(nationalityCombo, 1, 1);

        grid.add(new Label("Contact Number:"), 0, 2);
        grid.add(contactField, 1, 2);

        grid.add(new Label("Emergency Contact:"), 0, 3);
        grid.add(emergencyContactField, 1, 3);

        grid.add(new Label("Email:"), 0, 4);
        grid.add(emailField, 1, 4);

        grid.add(new Label("Username:"), 0, 5);
        grid.add(usernameField, 1, 5);

        grid.add(new Label("Password:"), 0, 6);
        grid.add(passwordField, 1, 6);

        grid.add(new Label("Confirm Password:"), 0, 7);
        grid.add(confirmPasswordField, 1, 7);

        // Terms and conditions
        CheckBox termsCheckBox = new CheckBox("I agree to the Terms and Conditions of Tours Nepal");
        termsCheckBox.getStyleClass().add("terms-checkbox");

        // Register button
        Button registerButton = new Button("Register as Tourist");
        registerButton.getStyleClass().add("primary-button");
        registerButton.setOnAction(e -> {
            if (validateTouristRegistration(nameField, nationalityCombo, contactField,
                    emergencyContactField, usernameField, passwordField,
                    confirmPasswordField, termsCheckBox)) {

                registerTourist(nameField.getText(), nationalityCombo.getValue(),
                        contactField.getText(), emergencyContactField.getText(),
                        emailField.getText(), usernameField.getText(), passwordField.getText());
            }
        });

        form.getChildren().addAll(grid, termsCheckBox, registerButton);
        return form;
    }

    private VBox createGuideRegistrationForm() {
        VBox form = new VBox(15);
        form.setAlignment(Pos.CENTER);

        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(15);
        grid.setVgap(15);

        // Form fields
        TextField nameField = new TextField();
        nameField.setPromptText("Full Name");

        TextField contactField = new TextField();
        contactField.setPromptText("Contact Number");

        TextField emailField = new TextField();
        emailField.setPromptText("Email Address (Optional)");

        // Languages selection
        VBox languagesBox = new VBox(5);
        Label languagesLabel = new Label("Languages Spoken:");

        CheckBox nepaliCheck = new CheckBox("Nepali");
        nepaliCheck.getStyleClass().add("language-checkbox");
        CheckBox englishCheck = new CheckBox("English");
        englishCheck.getStyleClass().add("language-checkbox");
        CheckBox hindiCheck = new CheckBox("Hindi");
        hindiCheck.getStyleClass().add("language-checkbox");
        CheckBox chineseCheck = new CheckBox("Chinese");
        chineseCheck.getStyleClass().add("language-checkbox");
        CheckBox frenchCheck = new CheckBox("French");
        frenchCheck.getStyleClass().add("language-checkbox");
        CheckBox germanCheck = new CheckBox("German");
        germanCheck.getStyleClass().add("language-checkbox");
        CheckBox japaneseCheck = new CheckBox("Japanese");
        japaneseCheck.getStyleClass().add("language-checkbox");
        CheckBox koreanCheck = new CheckBox("Korean");
        koreanCheck.getStyleClass().add("language-checkbox");

        // Default selections
        nepaliCheck.setSelected(true);
        englishCheck.setSelected(true);

        HBox languageRow1 = new HBox(10);
        languageRow1.getChildren().addAll(nepaliCheck, englishCheck, hindiCheck, chineseCheck);

        HBox languageRow2 = new HBox(10);
        languageRow2.getChildren().addAll(frenchCheck, germanCheck, japaneseCheck, koreanCheck);

        languagesBox.getChildren().addAll(languagesLabel, languageRow1, languageRow2);

        ComboBox<String> experienceCombo = new ComboBox<>();
        experienceCombo.getItems().addAll(
            "Less than 1 year", "1-2 years", "3-5 years",
            "6-10 years", "11-15 years", "More than 15 years"
        );
        experienceCombo.setPromptText("Select Experience Level");

        TextArea specializationArea = new TextArea();
        specializationArea.setPromptText("Specializations (e.g., Mountain trekking, Cultural tours, Wildlife safaris...)");
        specializationArea.setPrefRowCount(3);

        TextField licenseField = new TextField();
        licenseField.setPromptText("Guide License Number (if any)");

        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");

        PasswordField confirmPasswordField = new PasswordField();
        confirmPasswordField.setPromptText("Confirm Password");

        // Add fields to grid
        grid.add(new Label("Full Name:"), 0, 0);
        grid.add(nameField, 1, 0);

        grid.add(new Label("Contact Number:"), 0, 1);
        grid.add(contactField, 1, 1);

        grid.add(new Label("Email:"), 0, 2);
        grid.add(emailField, 1, 2);

        grid.add(new Label("Experience:"), 0, 3);
        grid.add(experienceCombo, 1, 3);

        grid.add(new Label("License Number:"), 0, 4);
        grid.add(licenseField, 1, 4);

        grid.add(new Label("Username:"), 0, 5);
        grid.add(usernameField, 1, 5);

        grid.add(new Label("Password:"), 0, 6);
        grid.add(passwordField, 1, 6);

        grid.add(new Label("Confirm Password:"), 0, 7);
        grid.add(confirmPasswordField, 1, 7);

        // Terms and conditions
        CheckBox termsCheckBox = new CheckBox("I agree to the Terms and Conditions of Tours Nepal");
        termsCheckBox.getStyleClass().add("terms-checkbox");

        CheckBox verificationCheckBox = new CheckBox("I certify that all information provided is accurate");
        verificationCheckBox.getStyleClass().add("terms-checkbox");

        // Register button
        Button registerButton = new Button("Register as Guide");
        registerButton.getStyleClass().add("primary-button");
        registerButton.setOnAction(e -> {
            List<CheckBox> languageCheckBoxes = Arrays.asList(
                nepaliCheck, englishCheck, hindiCheck, chineseCheck,
                frenchCheck, germanCheck, japaneseCheck, koreanCheck
            );

            if (validateGuideRegistration(nameField, contactField, experienceCombo,
                    usernameField, passwordField, confirmPasswordField,
                    languageCheckBoxes, termsCheckBox, verificationCheckBox)) {

                registerGuide(nameField.getText(), contactField.getText(), emailField.getText(),
                        getSelectedLanguages(languageCheckBoxes),
                        convertExperienceToYears(experienceCombo.getValue()),
                        specializationArea.getText(), licenseField.getText(),
                        usernameField.getText(), passwordField.getText());
            }
        });

        form.getChildren().addAll(grid, languagesBox,
                new Label("Specializations:"), specializationArea,
                termsCheckBox, verificationCheckBox, registerButton);
        return form;
    }

    private boolean validateTouristRegistration(TextField nameField, ComboBox<String> nationalityCombo,
            TextField contactField, TextField emergencyContactField, TextField usernameField,
            PasswordField passwordField, PasswordField confirmPasswordField, CheckBox termsCheckBox) {

        // Check required fields
        if (nameField.getText().trim().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please enter your full name.");
            return false;
        }

        if (nationalityCombo.getValue() == null || nationalityCombo.getValue().trim().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please select your nationality.");
            return false;
        }

        if (contactField.getText().trim().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please enter your contact number.");
            return false;
        }

        if (emergencyContactField.getText().trim().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please enter an emergency contact.");
            return false;
        }

        if (usernameField.getText().trim().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please enter a username.");
            return false;
        }

        if (passwordField.getText().trim().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please enter a password.");
            return false;
        }

        // Check password confirmation
        if (!passwordField.getText().equals(confirmPasswordField.getText())) {
            showAlert(Alert.AlertType.ERROR, "Error", "Passwords do not match.");
            return false;
        }

        // Check password strength
        if (passwordField.getText().length() < 6) {
            showAlert(Alert.AlertType.ERROR, "Error", "Password must be at least 6 characters long.");
            return false;
        }

        // Check username uniqueness
        if (isUsernameExists(usernameField.getText())) {
            showAlert(Alert.AlertType.ERROR, "Error", "Username already exists. Please choose a different username.");
            return false;
        }

        // Check terms acceptance
        if (!termsCheckBox.isSelected()) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please accept the Terms and Conditions.");
            return false;
        }

        return true;
    }

    private boolean validateGuideRegistration(TextField nameField, TextField contactField,
            ComboBox<String> experienceCombo, TextField usernameField, PasswordField passwordField,
            PasswordField confirmPasswordField, List<CheckBox> languageCheckBoxes,
            CheckBox termsCheckBox, CheckBox verificationCheckBox) {

        // Check required fields
        if (nameField.getText().trim().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please enter your full name.");
            return false;
        }

        if (contactField.getText().trim().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please enter your contact number.");
            return false;
        }

        if (experienceCombo.getValue() == null) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please select your experience level.");
            return false;
        }

        if (usernameField.getText().trim().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please enter a username.");
            return false;
        }

        if (passwordField.getText().trim().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please enter a password.");
            return false;
        }

        // Check password confirmation
        if (!passwordField.getText().equals(confirmPasswordField.getText())) {
            showAlert(Alert.AlertType.ERROR, "Error", "Passwords do not match.");
            return false;
        }

        // Check password strength
        if (passwordField.getText().length() < 6) {
            showAlert(Alert.AlertType.ERROR, "Error", "Password must be at least 6 characters long.");
            return false;
        }

        // Check username uniqueness
        if (isUsernameExists(usernameField.getText())) {
            showAlert(Alert.AlertType.ERROR, "Error", "Username already exists. Please choose a different username.");
            return false;
        }

        // Check at least one language is selected
        boolean hasLanguage = languageCheckBoxes.stream().anyMatch(CheckBox::isSelected);
        if (!hasLanguage) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please select at least one language.");
            return false;
        }

        // Check terms acceptance
        if (!termsCheckBox.isSelected()) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please accept the Terms and Conditions.");
            return false;
        }

        if (!verificationCheckBox.isSelected()) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please certify that your information is accurate.");
            return false;
        }

        return true;
    }

    private boolean isUsernameExists(String username) {
        // Check in tourists
        boolean existsInTourists = dataManager.getAllTourists().values().stream()
                .anyMatch(tourist -> tourist.getUsername().equals(username));

        // Check in guides
        boolean existsInGuides = dataManager.getAllGuides().values().stream()
                .anyMatch(guide -> guide.getUsername().equals(username));

        // Check admin username
        boolean isAdmin = "admin".equals(username);

        return existsInTourists || existsInGuides || isAdmin;
    }

    private List<String> getSelectedLanguages(List<CheckBox> languageCheckBoxes) {
        return languageCheckBoxes.stream()
                .filter(CheckBox::isSelected)
                .map(checkBox -> checkBox.getText())
                .collect(java.util.stream.Collectors.toList());
    }

    private int convertExperienceToYears(String experience) {
        switch (experience) {
            case "Less than 1 year": return 0;
            case "1-2 years": return 2;
            case "3-5 years": return 4;
            case "6-10 years": return 8;
            case "11-15 years": return 13;
            case "More than 15 years": return 20;
            default: return 1;
        }
    }

    private void registerTourist(String name, String nationality, String contact,
            String emergencyContact, String email, String username, String password) {

        Tourist newTourist = new Tourist(
            dataManager.generateTouristId(),
            name,
            nationality,
            contact,
            emergencyContact,
            username,
            password
        );

        // Set email if provided
        if (!email.trim().isEmpty()) {
            newTourist.setEmail(email);
        }

        dataManager.addTourist(newTourist);

        Alert success = new Alert(Alert.AlertType.INFORMATION);
        success.setTitle("Registration Successful");
        success.setHeaderText("Welcome to Tours Nepal!");
        success.setContentText("Your tourist account has been created successfully.\n\n" +
                "Tourist ID: " + newTourist.getId() + "\n" +
                "Username: " + username + "\n\n" +
                "You can now login and start booking amazing tours in Nepal!");
        success.showAndWait();

        // Return to login screen
        LoginController loginController = new LoginController();
        loginController.showLoginScreen(primaryStage);
    }

    private void registerGuide(String name, String contact, String email, List<String> languages,
            int experience, String specializations, String license, String username, String password) {

        Guide newGuide = new Guide(
            dataManager.generateGuideId(),
            name,
            languages,
            experience,
            contact,
            username,
            password
        );

        // Set additional fields if provided
        if (!email.trim().isEmpty()) {
            newGuide.setEmail(email);
        }
        if (!specializations.trim().isEmpty()) {
            newGuide.setSpecializations(specializations);
        }
        if (!license.trim().isEmpty()) {
            newGuide.setLicenseNumber(license);
        }

        dataManager.addGuide(newGuide);

        Alert success = new Alert(Alert.AlertType.INFORMATION);
        success.setTitle("Registration Successful");
        success.setHeaderText("Welcome to Tours Nepal Guide Network!");
        success.setContentText("Your guide account has been created successfully.\n\n" +
                "Guide ID: " + newGuide.getId() + "\n" +
                "Username: " + username + "\n" +
                "Languages: " + String.join(", ", languages) + "\n\n" +
                "You can now login and start accepting tour bookings!\n" +
                "Note: Your account may require admin approval before activation.");
        success.showAndWait();

        // Return to login screen
        LoginController loginController = new LoginController();
        loginController.showLoginScreen(primaryStage);
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
