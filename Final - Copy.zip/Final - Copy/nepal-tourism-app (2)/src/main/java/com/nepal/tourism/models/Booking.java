package com.nepal.tourism.models;

import java.io.Serializable;
import java.time.LocalDate;

public class Booking implements Serializable {
    private String id;
    private String touristId;
    private String guideId;
    private String attractionId;
    private LocalDate date;
    private String status;
    
    public Booking() {}
    
    public Booking(String id, String touristId, String guideId, String attractionId, 
                   LocalDate date, String status) {
        this.id = id;
        this.touristId = touristId;
        this.guideId = guideId;
        this.attractionId = attractionId;
        this.date = date;
        this.status = status;
    }
    
    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getTouristId() { return touristId; }
    public void setTouristId(String touristId) { this.touristId = touristId; }
    
    public String getGuideId() { return guideId; }
    public void setGuideId(String guideId) { this.guideId = guideId; }
    
    public String getAttractionId() { return attractionId; }
    public void setAttractionId(String attractionId) { this.attractionId = attractionId; }
    
    public LocalDate getDate() { return date; }
    public void setDate(LocalDate date) { this.date = date; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
