package com.nepal.tourism.models;

import java.io.Serializable;
import java.util.List;

public class Guide implements Serializable {
    private String id;
    private String name;
    private List<String> languages;
    private int experience;
    private String contact;
    private String username;
    private String password;
    private String email;
    private String specializations;
    private String licenseNumber;

    public Guide() {}

    // 10-parameter constructor
    public Guide(String id, String name, List<String> languages, int experience,
                 String contact, String username, String password, String email,
                 String specializations, String licenseNumber) {
        this.id = id;
        this.name = name;
        this.languages = languages;
        this.experience = experience;
        this.contact = contact;
        this.username = username;
        this.password = password;
        this.email = email;
        this.specializations = specializations;
        this.licenseNumber = licenseNumber;
    }

    // 7-parameter constructor (defaults last 3 fields to null)
    public Guide(String id, String name, List<String> languages, int experience,
                 String contact, String username, String password) {
        this(id, name, languages, experience, contact, username, password, null, null, null);
    }

    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public List<String> getLanguages() { return languages; }
    public void setLanguages(List<String> languages) { this.languages = languages; }

    public int getExperience() { return experience; }
    public void setExperience(int experience) { this.experience = experience; }

    public String getContact() { return contact; }
    public void setContact(String contact) { this.contact = contact; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getSpecializations() { return specializations; }
    public void setSpecializations(String specializations) { this.specializations = specializations; }

    public String getLicenseNumber() { return licenseNumber; }
    public void setLicenseNumber(String licenseNumber) { this.licenseNumber = licenseNumber; }

    @Override
    public String toString() {
        return name + " (" + experience + " years exp)";
    }
}