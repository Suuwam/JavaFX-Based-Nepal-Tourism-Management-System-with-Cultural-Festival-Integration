package com.nepal.tourism.controllers;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import com.nepal.tourism.models.*;
import com.nepal.tourism.utils.DataManager;
import com.nepal.tourism.utils.LanguageManager;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

public class AdminController implements DataManager.DataChangeListener {
    private Stage primaryStage;
    private LanguageManager langManager = LanguageManager.getInstance();
    private DataManager dataManager = DataManager.getInstance();
    private TabPane tabPane;

    // Observable lists for real-time updates
    private ObservableList<Tourist> touristsList = FXCollections.observableArrayList();
    private ObservableList<Guide> guidesList = FXCollections.observableArrayList();
    private ObservableList<Attraction> attractionsList = FXCollections.observableArrayList();
    private ObservableList<BookingDisplay> bookingsList = FXCollections.observableArrayList();
    private ObservableList<EmergencyReport> emergencyReportsList = FXCollections.observableArrayList();

    // Charts for real-time updates
    private PieChart nationalityChart;
    private BarChart<String, Number> attractionChart;

    // Statistics labels
    private Label totalTouristsLabel;
    private Label totalGuidesLabel;
    private Label totalAttractionsLabel;
    private Label totalBookingsLabel;

    public void showAdminDashboard(Stage stage) {
        this.primaryStage = stage;

        // Register for data change notifications
        dataManager.addDataChangeListener(this);

        BorderPane root = new BorderPane();
        root.getStyleClass().add("admin-dashboard");

        // Top menu bar
        MenuBar menuBar = createMenuBar();
        root.setTop(menuBar);

        // Main content with tabs
        tabPane = new TabPane();
        tabPane.getTabs().addAll(
            createDashboardTab(),
            createTouristsTab(),
            createGuidesTab(),
            createAttractionsTab(),
            createBookingsTab(),
            createReportsTab(),
            createFestivalDiscountsTab() // New tab for discounts
        );

        root.setCenter(tabPane);

        // Load initial data
        refreshAllData();

        Scene scene = new Scene(root, 1200, 800);
        scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());

        primaryStage.setTitle("Tours Nepal - " + langManager.getText("admin") + " " + langManager.getText("dashboard"));
        primaryStage.setScene(scene);
        primaryStage.setOnCloseRequest(e -> {
            dataManager.removeDataChangeListener(this);
            dataManager.saveDataToFile();
        });
        primaryStage.show();
    }

    @Override
    public void onDataChanged(String dataType, String operation, Object data) {
        // Update UI on JavaFX Application Thread
        Platform.runLater(() -> {
            System.out.println("Admin Dashboard: Data changed - " + dataType + " " + operation);
            refreshAllData();
        });
    }

    private void refreshAllData() {
        // Refresh all observable lists
        touristsList.setAll(dataManager.getAllTourists().values());
        guidesList.setAll(dataManager.getAllGuides().values());
        attractionsList.setAll(dataManager.getAllAttractions().values());
        emergencyReportsList.setAll(dataManager.getAllEmergencyReports());

        // Refresh bookings display
        bookingsList.clear();
        dataManager.getAllBookings().values().forEach(booking -> {
            Tourist tourist = dataManager.getTourist(booking.getTouristId());
            Guide guide = dataManager.getGuide(booking.getGuideId());
            Attraction attraction = dataManager.getAttraction(booking.getAttractionId());

            bookingsList.add(new BookingDisplay(
                booking.getId(),
                tourist != null ? tourist.getName() : "Unknown",
                guide != null ? guide.getName() : "Unknown",
                attraction != null ? attraction.getName() : "Unknown",
                booking.getDate(),
                booking.getStatus()
            ));
        });

        // Update statistics
        if (totalTouristsLabel != null) {
            totalTouristsLabel.setText(String.valueOf(dataManager.getAllTourists().size()));
            totalGuidesLabel.setText(String.valueOf(dataManager.getAllGuides().size()));
            totalAttractionsLabel.setText(String.valueOf(dataManager.getAllAttractions().size()));
            totalBookingsLabel.setText(String.valueOf(dataManager.getAllBookings().size()));
        }

        // Update charts
        updateCharts();
    }

    private void updateCharts() {
        if (nationalityChart != null) {
            Map<String, Long> nationalityCount = dataManager.getAllTourists().values().stream()
                .collect(Collectors.groupingBy(Tourist::getNationality, Collectors.counting()));

            ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList();
            nationalityCount.forEach((nationality, count) ->
                pieChartData.add(new PieChart.Data(nationality, count)));

            nationalityChart.setData(pieChartData);
        }

        if (attractionChart != null) {
            Map<String, Long> attractionCount = dataManager.getAllBookings().values().stream()
                .collect(Collectors.groupingBy(Booking::getAttractionId, Collectors.counting()));

            XYChart.Series<String, Number> series = new XYChart.Series<>();
            series.setName("Bookings");

            attractionCount.forEach((attractionId, count) -> {
                Attraction attraction = dataManager.getAttraction(attractionId);
                if (attraction != null) {
                    series.getData().add(new XYChart.Data<>(attraction.getName(), count));
                }
            });

            attractionChart.getData().clear();
            attractionChart.getData().add(series);
        }
    }

    private MenuBar createMenuBar() {
        MenuBar menuBar = new MenuBar();

        Menu fileMenu = new Menu("File");
        MenuItem saveItem = new MenuItem("Save Data");
        MenuItem loadItem = new MenuItem("Load Data");
        MenuItem logoutItem = new MenuItem(langManager.getText("logout"));

        saveItem.setOnAction(e -> {
            dataManager.saveDataToFile();
            showAlert(Alert.AlertType.INFORMATION, "Success", "Data saved successfully!");
        });

        loadItem.setOnAction(e -> {
            dataManager.loadDataFromFile();
            refreshAllData();
            showAlert(Alert.AlertType.INFORMATION, "Success", "Data loaded successfully!");
        });

        logoutItem.setOnAction(e -> {
            dataManager.removeDataChangeListener(this);
            dataManager.saveDataToFile();
            LoginController loginController = new LoginController();
            loginController.showLoginScreen(primaryStage);
        });

        fileMenu.getItems().addAll(saveItem, loadItem, new SeparatorMenuItem(), logoutItem);

        Menu languageMenu = new Menu(langManager.getText("language"));
        MenuItem englishItem = new MenuItem("English");
        MenuItem nepaliItem = new MenuItem("नेपाली");

        englishItem.setOnAction(e -> {
            langManager.setLanguage("en");
            showAdminDashboard(primaryStage);
        });

        nepaliItem.setOnAction(e -> {
            langManager.setLanguage("ne");
            showAdminDashboard(primaryStage);
        });

        languageMenu.getItems().addAll(englishItem, nepaliItem);
        menuBar.getMenus().addAll(fileMenu, languageMenu);

        return menuBar;
    }

    private Tab createDashboardTab() {
        Tab tab = new Tab(langManager.getText("dashboard"));
        tab.setClosable(false);

        VBox content = new VBox(20);
        content.setPadding(new Insets(20));

        // Statistics cards
        HBox statsBox = new HBox(20);
        VBox touristsCard = createStatCard("Total Tourists", "0");
        VBox guidesCard = createStatCard("Total Guides", "0");
        VBox attractionsCard = createStatCard("Total Attractions", "0");
        VBox bookingsCard = createStatCard("Total Bookings", "0");

        // Store references to labels for updates
        totalTouristsLabel = (Label) touristsCard.getChildren().get(1);
        totalGuidesLabel = (Label) guidesCard.getChildren().get(1);
        totalAttractionsLabel = (Label) attractionsCard.getChildren().get(1);
        totalBookingsLabel = (Label) bookingsCard.getChildren().get(1);

        statsBox.getChildren().addAll(touristsCard, guidesCard, attractionsCard, bookingsCard);

        // Charts
        HBox chartsBox = new HBox(20);
        nationalityChart = createNationalityChart();
        attractionChart = createAttractionChart();
        chartsBox.getChildren().addAll(nationalityChart, attractionChart);

        content.getChildren().addAll(statsBox, chartsBox);
        tab.setContent(new ScrollPane(content));

        return tab;
    }

    private VBox createStatCard(String title, String value) {
        VBox card = new VBox(10);
        card.getStyleClass().add("stat-card");
        card.setPadding(new Insets(20));

        Label titleLabel = new Label(title);
        titleLabel.getStyleClass().add("stat-title");

        Label valueLabel = new Label(value);
        valueLabel.getStyleClass().add("stat-value");

        card.getChildren().addAll(titleLabel, valueLabel);
        return card;
    }

    private PieChart createNationalityChart() {
        PieChart chart = new PieChart();
        chart.setTitle("Tourists by Nationality");
        chart.setPrefSize(400, 300);
        return chart;
    }

    private BarChart<String, Number> createAttractionChart() {
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        BarChart<String, Number> chart = new BarChart<>(xAxis, yAxis);
        chart.setTitle("Popular Attractions");
        chart.setPrefSize(400, 300);
        return chart;
    }

    private Tab createTouristsTab() {
        Tab tab = new Tab(langManager.getText("tourists"));
        tab.setClosable(false);

        VBox content = new VBox(10);
        content.setPadding(new Insets(20));

        // Buttons
        HBox buttonBox = new HBox(10);
        Button addButton = new Button(langManager.getText("add") + " " + langManager.getText("tourist"));
        Button editButton = new Button(langManager.getText("edit"));
        Button deleteButton = new Button(langManager.getText("delete"));

        addButton.getStyleClass().add("primary-button");
        editButton.getStyleClass().add("secondary-button");
        deleteButton.getStyleClass().add("danger-button");

        buttonBox.getChildren().addAll(addButton, editButton, deleteButton);

        // Table
        TableView<Tourist> table = new TableView<>();
        table.setItems(touristsList);
        table.getColumns().addAll(
            createTableColumn("ID", "id"),
            createTableColumn(langManager.getText("name"), "name"),
            createTableColumn(langManager.getText("nationality"), "nationality"),
            createTableColumn(langManager.getText("contact"), "contact"),
            createTableColumn(langManager.getText("emergency_contact"), "emergencyContact")
        );

        // Button actions
        addButton.setOnAction(e -> showTouristForm(null));
        editButton.setOnAction(e -> {
            Tourist selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                showTouristForm(selected);
            } else {
                showAlert(Alert.AlertType.WARNING, "Warning", "Please select a tourist to edit.");
            }
        });
        deleteButton.setOnAction(e -> {
            Tourist selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
                confirmation.setTitle("Confirm Deletion");
                confirmation.setHeaderText("Delete Tourist");
                confirmation.setContentText("Are you sure you want to delete " + selected.getName() + "?");

                if (confirmation.showAndWait().get() == ButtonType.OK) {
                    dataManager.deleteTourist(selected.getId());
                }
            } else {
                showAlert(Alert.AlertType.WARNING, "Warning", "Please select a tourist to delete.");
            }
        });

        content.getChildren().addAll(buttonBox, table);
        tab.setContent(content);

        return tab;
    }

    private Tab createGuidesTab() {
        Tab tab = new Tab(langManager.getText("guides"));
        tab.setClosable(false);

        VBox content = new VBox(10);
        content.setPadding(new Insets(20));

        // Buttons
        HBox buttonBox = new HBox(10);
        Button addButton = new Button(langManager.getText("add") + " " + langManager.getText("guide"));
        Button editButton = new Button(langManager.getText("edit"));
        Button deleteButton = new Button(langManager.getText("delete"));

        addButton.getStyleClass().add("primary-button");
        editButton.getStyleClass().add("secondary-button");
        deleteButton.getStyleClass().add("danger-button");

        buttonBox.getChildren().addAll(addButton, editButton, deleteButton);

        // Table
        TableView<Guide> table = new TableView<>();
        table.setItems(guidesList);
        table.getColumns().addAll(
            createTableColumn("ID", "id"),
            createTableColumn(langManager.getText("name"), "name"),
            createTableColumn(langManager.getText("experience"), "experience"),
            createTableColumn(langManager.getText("contact"), "contact")
        );

        // Button actions
        addButton.setOnAction(e -> showGuideForm(null));
        editButton.setOnAction(e -> {
            Guide selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                showGuideForm(selected);
            } else {
                showAlert(Alert.AlertType.WARNING, "Warning", "Please select a guide to edit.");
            }
        });
        deleteButton.setOnAction(e -> {
            Guide selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
                confirmation.setTitle("Confirm Deletion");
                confirmation.setHeaderText("Delete Guide");
                confirmation.setContentText("Are you sure you want to delete " + selected.getName() + "?");

                if (confirmation.showAndWait().get() == ButtonType.OK) {
                    dataManager.deleteGuide(selected.getId());
                }
            } else {
                showAlert(Alert.AlertType.WARNING, "Warning", "Please select a guide to delete.");
            }
        });

        content.getChildren().addAll(buttonBox, table);
        tab.setContent(content);

        return tab;
    }

    private Tab createAttractionsTab() {
        Tab tab = new Tab(langManager.getText("attractions"));
        tab.setClosable(false);

        VBox content = new VBox(10);
        content.setPadding(new Insets(20));

        // Buttons
        HBox buttonBox = new HBox(10);
        Button addButton = new Button(langManager.getText("add") + " Attraction");
        Button editButton = new Button(langManager.getText("edit"));
        Button deleteButton = new Button(langManager.getText("delete"));

        addButton.getStyleClass().add("primary-button");
        editButton.getStyleClass().add("secondary-button");
        deleteButton.getStyleClass().add("danger-button");

        buttonBox.getChildren().addAll(addButton, editButton, deleteButton);

        // Table
        TableView<Attraction> table = new TableView<>();
        table.setItems(attractionsList);
        table.getColumns().addAll(
            createTableColumn("ID", "id"),
            createTableColumn(langManager.getText("name"), "name"),
            createTableColumn(langManager.getText("type"), "type"),
            createTableColumn(langManager.getText("location"), "location"),
            createTableColumn(langManager.getText("difficulty"), "difficulty")
        );

        // Button actions
        addButton.setOnAction(e -> showAttractionForm(null));
        editButton.setOnAction(e -> {
            Attraction selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                showAttractionForm(selected);
            } else {
                showAlert(Alert.AlertType.WARNING, "Warning", "Please select an attraction to edit.");
            }
        });
        deleteButton.setOnAction(e -> {
            Attraction selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
                confirmation.setTitle("Confirm Deletion");
                confirmation.setHeaderText("Delete Attraction");
                confirmation.setContentText("Are you sure you want to delete " + selected.getName() + "?");

                if (confirmation.showAndWait().get() == ButtonType.OK) {
                    dataManager.deleteAttraction(selected.getId());
                }
            } else {
                showAlert(Alert.AlertType.WARNING, "Warning", "Please select an attraction to delete.");
            }
        });

        content.getChildren().addAll(buttonBox, table);
        tab.setContent(content);

        return tab;
    }

    private Tab createBookingsTab() {
        Tab tab = new Tab(langManager.getText("bookings"));
        tab.setClosable(false);

        VBox content = new VBox(10);
        content.setPadding(new Insets(20));

        // Buttons
        HBox buttonBox = new HBox(10);
        Button addButton = new Button(langManager.getText("add") + " Booking");
        Button editButton = new Button(langManager.getText("edit"));
        Button deleteButton = new Button(langManager.getText("delete"));

        addButton.getStyleClass().add("primary-button");
        editButton.getStyleClass().add("secondary-button");
        deleteButton.getStyleClass().add("danger-button");

        buttonBox.getChildren().addAll(addButton, editButton, deleteButton);

        // Table
        TableView<BookingDisplay> table = new TableView<>();
        table.setItems(bookingsList);
        table.getColumns().addAll(
            createTableColumn("ID", "id"),
            createTableColumn("Tourist", "touristName"),
            createTableColumn("Guide", "guideName"),
            createTableColumn("Attraction", "attractionName"),
            createTableColumn(langManager.getText("date"), "date"),
            createTableColumn(langManager.getText("status"), "status")
        );

        // Button actions
        addButton.setOnAction(e -> showBookingForm(null));
        editButton.setOnAction(e -> {
            BookingDisplay selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                Booking booking = dataManager.getBooking(selected.getId());
                if (booking != null) {
                    showBookingForm(booking);
                }
            } else {
                showAlert(Alert.AlertType.WARNING, "Warning", "Please select a booking to edit.");
            }
        });
        deleteButton.setOnAction(e -> {
            BookingDisplay selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
                confirmation.setTitle("Confirm Deletion");
                confirmation.setHeaderText("Delete Booking");
                confirmation.setContentText("Are you sure you want to delete booking " + selected.getId() + "?");

                if (confirmation.showAndWait().get() == ButtonType.OK) {
                    dataManager.deleteBooking(selected.getId());
                }
            } else {
                showAlert(Alert.AlertType.WARNING, "Warning", "Please select a booking to delete.");
            }
        });

        content.getChildren().addAll(buttonBox, table);
        tab.setContent(content);

        return tab;
    }

    private Tab createReportsTab() {
        Tab tab = new Tab(langManager.getText("reports"));
        tab.setClosable(false);

        VBox content = new VBox(10);
        content.setPadding(new Insets(20));

        Label titleLabel = new Label("Emergency Reports");
        titleLabel.getStyleClass().add("section-title");

        // Table for emergency reports
        TableView<EmergencyReport> table = new TableView<>();
        table.setItems(emergencyReportsList);
        table.getColumns().addAll(
            createTableColumn("ID", "id"),
            createTableColumn("Booking ID", "bookingId"),
            createTableColumn("Description", "description"),
            createTableColumn("Timestamp", "timestamp"),
            createTableColumn("Reported By", "reportedBy")
        );

        content.getChildren().addAll(titleLabel, table);
        tab.setContent(content);

        return tab;
    }

    private Tab createFestivalDiscountsTab() {
        Tab tab = new Tab("Festival Discounts");
        tab.setClosable(false);
        VBox content = new VBox(10);
        content.setPadding(new Insets(20));
        TableView<FestivalDiscount> table = new TableView<>();
        ObservableList<FestivalDiscount> discountList = FXCollections.observableArrayList(dataManager.getFestivalDiscounts());
        table.setItems(discountList);
        table.getColumns().addAll(
            createTableColumn("Name", "name"),
            createTableColumn("Percentage", "percentage"),
            createTableColumn("Start Date", "startDate"),
            createTableColumn("End Date", "endDate"),
            createTableColumn("Description", "description")
        );
        Button addButton = new Button("Add Discount");
        addButton.setOnAction(e -> showAddDiscountDialog(discountList));
        content.getChildren().addAll(addButton, table);
        tab.setContent(content);
        return tab;
    }

    private void showAddDiscountDialog(ObservableList<FestivalDiscount> discountList) {
        Stage dialog = new Stage();
        dialog.setTitle("Add Festival Discount");
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20));
        TextField nameField = new TextField();
        TextField percentField = new TextField();
        DatePicker startDate = new DatePicker();
        DatePicker endDate = new DatePicker();
        TextField descField = new TextField();
        grid.add(new Label("Name:"), 0, 0);
        grid.add(nameField, 1, 0);
        grid.add(new Label("Percentage (%):"), 0, 1);
        grid.add(percentField, 1, 1);
        grid.add(new Label("Start Date:"), 0, 2);
        grid.add(startDate, 1, 2);
        grid.add(new Label("End Date:"), 0, 3);
        grid.add(endDate, 1, 3);
        grid.add(new Label("Description:"), 0, 4);
        grid.add(descField, 1, 4);
        Button saveButton = new Button("Save");
        saveButton.setOnAction(e -> {
            try {
                double percent = Double.parseDouble(percentField.getText());
                FestivalDiscount discount = new FestivalDiscount(
                    "FD" + System.currentTimeMillis(),
                    nameField.getText(),
                    percent,
                    startDate.getValue(),
                    endDate.getValue(),
                    descField.getText()
                );
                dataManager.addFestivalDiscount(discount);
                discountList.setAll(dataManager.getFestivalDiscounts());
                dialog.close();
            } catch (Exception ex) {
                showAlert(Alert.AlertType.ERROR, "Error", "Invalid input for discount.");
            }
        });
        Button cancelButton = new Button("Cancel");
        cancelButton.setOnAction(e -> dialog.close());
        HBox buttonBox = new HBox(10, saveButton, cancelButton);
        grid.add(buttonBox, 1, 5);
        Scene scene = new Scene(grid, 1200, 800);
        dialog.setScene(scene);
        dialog.showAndWait();
    }

    private <T> TableColumn<T, String> createTableColumn(String title, String property) {
        TableColumn<T, String> column = new TableColumn<>(title);
        column.setCellValueFactory(new PropertyValueFactory<>(property));
        column.setPrefWidth(150);
        return column;
    }

    private void showTouristForm(Tourist tourist) {
        Stage dialog = new Stage();
        dialog.setTitle(tourist == null ? "Add Tourist" : "Edit Tourist");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20));

        TextField nameField = new TextField(tourist != null ? tourist.getName() : "");
        TextField nationalityField = new TextField(tourist != null ? tourist.getNationality() : "");
        TextField contactField = new TextField(tourist != null ? tourist.getContact() : "");
        TextField emergencyContactField = new TextField(tourist != null ? tourist.getEmergencyContact() : "");
        TextField usernameField = new TextField(tourist != null ? tourist.getUsername() : "");
        PasswordField passwordField = new PasswordField();
        if (tourist != null) passwordField.setText(tourist.getPassword());

        grid.add(new Label("Name:"), 0, 0);
        grid.add(nameField, 1, 0);
        grid.add(new Label("Nationality:"), 0, 1);
        grid.add(nationalityField, 1, 1);
        grid.add(new Label("Contact:"), 0, 2);
        grid.add(contactField, 1, 2);
        grid.add(new Label("Emergency Contact:"), 0, 3);
        grid.add(emergencyContactField, 1, 3);
        grid.add(new Label("Username:"), 0, 4);
        grid.add(usernameField, 1, 4);
        grid.add(new Label("Password:"), 0, 5);
        grid.add(passwordField, 1, 5);

        HBox buttonBox = new HBox(10);
        Button saveButton = new Button("Save");
        Button cancelButton = new Button("Cancel");

        saveButton.setOnAction(e -> {
            if (validateTouristForm(nameField, nationalityField, contactField, emergencyContactField, usernameField, passwordField)) {
                if (tourist == null) {
                    Tourist newTourist = new Tourist(
                        dataManager.generateTouristId(),
                        nameField.getText(),
                        nationalityField.getText(),
                        contactField.getText(),
                        emergencyContactField.getText(),
                        usernameField.getText(),
                        passwordField.getText()
                    );
                    dataManager.addTourist(newTourist);
                } else {
                    tourist.setName(nameField.getText());
                    tourist.setNationality(nationalityField.getText());
                    tourist.setContact(contactField.getText());
                    tourist.setEmergencyContact(emergencyContactField.getText());
                    tourist.setUsername(usernameField.getText());
                    tourist.setPassword(passwordField.getText());
                    dataManager.updateTourist(tourist);
                }
                dialog.close();
            }
        });

        cancelButton.setOnAction(e -> dialog.close());

        buttonBox.getChildren().addAll(saveButton, cancelButton);
        grid.add(buttonBox, 1, 6);

        Scene scene = new Scene(grid, 1200, 800);
        scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());
        dialog.setScene(scene);
        dialog.showAndWait();
    }

    private void showGuideForm(Guide guide) {
        Stage dialog = new Stage();
        dialog.setTitle(guide == null ? "Add Guide" : "Edit Guide");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20));

        TextField nameField = new TextField(guide != null ? guide.getName() : "");
        TextField languagesField = new TextField(guide != null ? String.join(", ", guide.getLanguages()) : "");
        TextField experienceField = new TextField(guide != null ? String.valueOf(guide.getExperience()) : "");
        TextField contactField = new TextField(guide != null ? guide.getContact() : "");
        TextField usernameField = new TextField(guide != null ? guide.getUsername() : "");
        PasswordField passwordField = new PasswordField();
        if (guide != null) passwordField.setText(guide.getPassword());

        grid.add(new Label("Name:"), 0, 0);
        grid.add(nameField, 1, 0);
        grid.add(new Label("Languages (comma separated):"), 0, 1);
        grid.add(languagesField, 1, 1);
        grid.add(new Label("Experience (years):"), 0, 2);
        grid.add(experienceField, 1, 2);
        grid.add(new Label("Contact:"), 0, 3);
        grid.add(contactField, 1, 3);
        grid.add(new Label("Username:"), 0, 4);
        grid.add(usernameField, 1, 4);
        grid.add(new Label("Password:"), 0, 5);
        grid.add(passwordField, 1, 5);

        HBox buttonBox = new HBox(10);
        Button saveButton = new Button("Save");
        Button cancelButton = new Button("Cancel");

        saveButton.setOnAction(e -> {
            if (validateGuideForm(nameField, languagesField, experienceField, contactField, usernameField, passwordField)) {
                try {
                    List<String> languages = Arrays.asList(languagesField.getText().split(",\\s*"));
                    int experience = Integer.parseInt(experienceField.getText());

                    if (guide == null) {
                        Guide newGuide = new Guide(
                            dataManager.generateGuideId(),
                            nameField.getText(),
                            languages,
                            experience,
                            contactField.getText(),
                            usernameField.getText(),
                            passwordField.getText()
                        );
                        dataManager.addGuide(newGuide);
                    } else {
                        guide.setName(nameField.getText());
                        guide.setLanguages(languages);
                        guide.setExperience(experience);
                        guide.setContact(contactField.getText());
                        guide.setUsername(usernameField.getText());
                        guide.setPassword(passwordField.getText());
                        dataManager.updateGuide(guide);
                    }
                    dialog.close();
                } catch (NumberFormatException ex) {
                    showAlert(Alert.AlertType.ERROR, "Error", "Experience must be a valid number.");
                }
            }
        });

        cancelButton.setOnAction(e -> dialog.close());

        buttonBox.getChildren().addAll(saveButton, cancelButton);
        grid.add(buttonBox, 1, 6);

        Scene scene = new Scene(grid, 1200, 800);
        scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());
        dialog.setScene(scene);
        dialog.showAndWait();
    }

    private void showAttractionForm(Attraction attraction) {
        Stage dialog = new Stage();
        dialog.setTitle(attraction == null ? "Add Attraction" : "Edit Attraction");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20));

        TextField nameField = new TextField(attraction != null ? attraction.getName() : "");
        ComboBox<String> typeCombo = new ComboBox<>();
        typeCombo.getItems().addAll("Trek", "Heritage", "Wildlife", "Adventure", "Cultural");
        typeCombo.setValue(attraction != null ? attraction.getType() : "Trek");

        TextField locationField = new TextField(attraction != null ? attraction.getLocation() : "");
        ComboBox<String> difficultyCombo = new ComboBox<>();
        difficultyCombo.getItems().addAll("Easy", "Medium", "Hard");
        difficultyCombo.setValue(attraction != null ? attraction.getDifficulty() : "Easy");

        TextField priceField = new TextField(attraction != null ? String.valueOf(attraction.getPrice()) : "");
        grid.add(new Label("Price:"), 0, 4);
        grid.add(priceField, 1, 4);
        grid.add(new Label("Name:"), 0, 0);
        grid.add(nameField, 1, 0);
        grid.add(new Label("Type:"), 0, 1);
        grid.add(typeCombo, 1, 1);
        grid.add(new Label("Location:"), 0, 2);
        grid.add(locationField, 1, 2);
        grid.add(new Label("Difficulty:"), 0, 3);
        grid.add(difficultyCombo, 1, 3);

        HBox buttonBox = new HBox(10);
        Button saveButton = new Button("Save");
        Button cancelButton = new Button("Cancel");

        saveButton.setOnAction(e -> {
            if (validateAttractionForm(nameField, locationField)) {
                try {
                    double price = Double.parseDouble(priceField.getText());
                    if (attraction == null) {
                        Attraction newAttraction = new Attraction(
                            dataManager.generateAttractionId(),
                            nameField.getText(),
                            typeCombo.getValue(),
                            locationField.getText(),
                            difficultyCombo.getValue(),
                            price
                        );
                        dataManager.addAttraction(newAttraction);
                    } else {
                        attraction.setName(nameField.getText());
                        attraction.setType(typeCombo.getValue());
                        attraction.setLocation(locationField.getText());
                        attraction.setDifficulty(difficultyCombo.getValue());
                        attraction.setPrice(price);
                        dataManager.updateAttraction(attraction);
                    }
                    dialog.close();
                } catch (NumberFormatException ex) {
                    showAlert(Alert.AlertType.ERROR, "Error", "Price must be a valid number.");
                }
            }
        });

        cancelButton.setOnAction(e -> dialog.close());

        buttonBox.getChildren().addAll(saveButton, cancelButton);
        grid.add(buttonBox, 1, 6);

        Scene scene = new Scene(grid, 1200, 800);
        scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());
        dialog.setScene(scene);
        dialog.showAndWait();
    }

    private void showBookingForm(Booking booking) {
        Stage dialog = new Stage();
        dialog.setTitle(booking == null ? "Add Booking" : "Edit Booking");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20));

        ComboBox<Tourist> touristCombo = new ComboBox<>();
        touristCombo.getItems().addAll(dataManager.getAllTourists().values());
        if (booking != null) {
            touristCombo.setValue(dataManager.getTourist(booking.getTouristId()));
        }

        ComboBox<Guide> guideCombo = new ComboBox<>();
        guideCombo.getItems().addAll(dataManager.getAllGuides().values());
        if (booking != null) {
            guideCombo.setValue(dataManager.getGuide(booking.getGuideId()));
        }

        ComboBox<Attraction> attractionCombo = new ComboBox<>();
        attractionCombo.getItems().addAll(dataManager.getAllAttractions().values());
        if (booking != null) {
            attractionCombo.setValue(dataManager.getAttraction(booking.getAttractionId()));
        }

        DatePicker datePicker = new DatePicker();
        datePicker.setValue(booking != null ? booking.getDate() : LocalDate.now().plusDays(1));

        ComboBox<String> statusCombo = new ComboBox<>();
        statusCombo.getItems().addAll("Pending", "Confirmed", "Cancelled", "Completed");
        statusCombo.setValue(booking != null ? booking.getStatus() : "Pending");

        grid.add(new Label("Tourist:"), 0, 0);
        grid.add(touristCombo, 1, 0);
        grid.add(new Label("Guide:"), 0, 1);
        grid.add(guideCombo, 1, 1);
        grid.add(new Label("Attraction:"), 0, 2);
        grid.add(attractionCombo, 1, 2);
        grid.add(new Label("Date:"), 0, 3);
        grid.add(datePicker, 1, 3);
        grid.add(new Label("Status:"), 0, 4);
        grid.add(statusCombo, 1, 4);

        HBox buttonBox = new HBox(10);
        Button saveButton = new Button("Save");
        Button cancelButton = new Button("Cancel");

        saveButton.setOnAction(e -> {
            if (touristCombo.getValue() != null && guideCombo.getValue() != null &&
                attractionCombo.getValue() != null && datePicker.getValue() != null) {

                if (booking == null) {
                    Booking newBooking = new Booking(
                        dataManager.generateBookingId(),
                        touristCombo.getValue().getId(),
                        guideCombo.getValue().getId(),
                        attractionCombo.getValue().getId(),
                        datePicker.getValue(),
                        statusCombo.getValue()
                    );
                    dataManager.addBooking(newBooking);
                } else {
                    booking.setTouristId(touristCombo.getValue().getId());
                    booking.setGuideId(guideCombo.getValue().getId());
                    booking.setAttractionId(attractionCombo.getValue().getId());
                    booking.setDate(datePicker.getValue());
                    booking.setStatus(statusCombo.getValue());
                    dataManager.updateBooking(booking);
                }
                dialog.close();
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Please fill in all fields.");
            }
        });

        cancelButton.setOnAction(e -> dialog.close());

        buttonBox.getChildren().addAll(saveButton, cancelButton);
        grid.add(buttonBox, 1, 5);

        Scene scene = new Scene(grid, 1200, 800);
        scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());
        dialog.setScene(scene);
        dialog.showAndWait();
    }

    private boolean validateTouristForm(TextField nameField, TextField nationalityField,
                                      TextField contactField, TextField emergencyContactField,
                                      TextField usernameField, PasswordField passwordField) {
        if (nameField.getText().trim().isEmpty() || nationalityField.getText().trim().isEmpty() ||
            contactField.getText().trim().isEmpty() || emergencyContactField.getText().trim().isEmpty() ||
            usernameField.getText().trim().isEmpty() || passwordField.getText().trim().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please fill in all fields.");
            return false;
        }
        return true;
    }

    private boolean validateGuideForm(TextField nameField, TextField languagesField,
                                    TextField experienceField, TextField contactField,
                                    TextField usernameField, PasswordField passwordField) {
        if (nameField.getText().trim().isEmpty() || languagesField.getText().trim().isEmpty() ||
            experienceField.getText().trim().isEmpty() || contactField.getText().trim().isEmpty() ||
            usernameField.getText().trim().isEmpty() || passwordField.getText().trim().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please fill in all fields.");
            return false;
        }
        return true;
    }

    private boolean validateAttractionForm(TextField nameField, TextField locationField) {
        if (nameField.getText().trim().isEmpty() || locationField.getText().trim().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please fill in all fields.");
            return false;
        }
        return true;
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // Helper class for booking display
    public static class BookingDisplay {
        private String id;
        private String touristName;
        private String guideName;
        private String attractionName;
        private LocalDate date;
        private String status;

        public BookingDisplay(String id, String touristName, String guideName,
                            String attractionName, LocalDate date, String status) {
            this.id = id;
            this.touristName = touristName;
            this.guideName = guideName;
            this.attractionName = attractionName;
            this.date = date;
            this.status = status;
        }

        // Getters
        public String getId() { return id; }
        public String getTouristName() { return touristName; }
        public String getGuideName() { return guideName; }
        public String getAttractionName() { return attractionName; }
        public LocalDate getDate() { return date; }
        public String getStatus() { return status; }
    }
}
