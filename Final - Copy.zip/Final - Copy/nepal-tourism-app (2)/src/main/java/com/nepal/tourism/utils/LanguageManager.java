package com.nepal.tourism.utils;

import java.util.HashMap;
import java.util.Map;

public class LanguageManager {
    private static LanguageManager instance;
    private String currentLanguage = "en";
    private Map<String, Map<String, String>> translations;
    
    private LanguageManager() {
        initializeTranslations();
    }
    
    public static LanguageManager getInstance() {
        if (instance == null) {
            instance = new LanguageManager();
        }
        return instance;
    }
    
    private void initializeTranslations() {
        translations = new HashMap<>();
        
        // English translations
        Map<String, String> english = new HashMap<>();
        english.put("login", "Login");
        english.put("username", "Username");
        english.put("password", "Password");
        english.put("admin", "Admin");
        english.put("tourist", "Tourist");
        english.put("guide", "Guide");
        english.put("dashboard", "Dashboard");
        english.put("bookings", "Bookings");
        english.put("attractions", "Attractions");
        english.put("guides", "Guides");
        english.put("tourists", "Tourists");
        english.put("reports", "Reports");
        english.put("emergency", "Emergency");
        english.put("add", "Add");
        english.put("edit", "Edit");
        english.put("delete", "Delete");
        english.put("save", "Save");
        english.put("cancel", "Cancel");
        english.put("name", "Name");
        english.put("nationality", "Nationality");
        english.put("contact", "Contact");
        english.put("emergency_contact", "Emergency Contact");
        english.put("languages", "Languages");
        english.put("experience", "Experience");
        english.put("type", "Type");
        english.put("location", "Location");
        english.put("difficulty", "Difficulty");
        english.put("date", "Date");
        english.put("status", "Status");
        english.put("logout", "Logout");
        english.put("language", "Language");
        english.put("statistics", "Statistics");
        english.put("report_emergency", "Report Emergency");
        english.put("view_bookings", "View Bookings");
        english.put("my_bookings", "My Bookings");
        english.put("create_booking", "Create Booking");
        
        // Nepali translations
        Map<String, String> nepali = new HashMap<>();
        nepali.put("login", "लगइन");
        nepali.put("username", "प्रयोगकर्ता नाम");
        nepali.put("password", "पासवर्ड");
        nepali.put("admin", "प्रशासक");
        nepali.put("tourist", "पर्यटक");
        nepali.put("guide", "गाइड");
        nepali.put("dashboard", "ड्यासबोर्ड");
        nepali.put("bookings", "बुकिङहरू");
        nepali.put("attractions", "आकर्षणहरू");
        nepali.put("guides", "गाइडहरू");
        nepali.put("tourists", "पर्यटकहरू");
        nepali.put("reports", "रिपोर्टहरू");
        nepali.put("emergency", "आपतकाल");
        nepali.put("add", "थप्नुहोस्");
        nepali.put("edit", "सम्पादन");
        nepali.put("delete", "मेटाउनुहोस्");
        nepali.put("save", "सेभ गर्नुहोस्");
        nepali.put("cancel", "रद्द गर्नुहोस्");
        nepali.put("name", "नाम");
        nepali.put("nationality", "राष्ट्रियता");
        nepali.put("contact", "सम्पर्क");
        nepali.put("emergency_contact", "आपतकालीन सम्पर्क");
        nepali.put("languages", "भाषाहरू");
        nepali.put("experience", "अनुभव");
        nepali.put("type", "प्रकार");
        nepali.put("location", "स्थान");
        nepali.put("difficulty", "कठिनाई");
        nepali.put("date", "मिति");
        nepali.put("status", "स्थिति");
        nepali.put("logout", "लगआउट");
        nepali.put("language", "भाषा");
        nepali.put("statistics", "तथ्याङ्क");
        nepali.put("report_emergency", "आपतकाल रिपोर्ट");
        nepali.put("view_bookings", "बुकिङहरू हेर्नुहोस्");
        nepali.put("my_bookings", "मेरा बुकिङहरू");
        nepali.put("create_booking", "बुकिङ सिर्जना");
        
        translations.put("en", english);
        translations.put("ne", nepali);
    }
    
    public void setLanguage(String language) {
        this.currentLanguage = language;
    }
    
    public String getCurrentLanguage() {
        return currentLanguage;
    }
    
    public String getText(String key) {
        Map<String, String> currentTranslations = translations.get(currentLanguage);
        return currentTranslations.getOrDefault(key, key);
    }
}
