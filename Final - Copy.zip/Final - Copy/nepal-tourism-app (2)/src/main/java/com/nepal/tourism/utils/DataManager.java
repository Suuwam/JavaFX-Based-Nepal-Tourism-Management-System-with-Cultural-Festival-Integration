package com.nepal.tourism.utils;

import com.nepal.tourism.models.*;
import java.io.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

public class DataManager {
    private static DataManager instance;
    private Map<String, Tourist> tourists;
    private Map<String, Guide> guides;
    private Map<String, Attraction> attractions;
    private Map<String, Booking> bookings;
    private List<EmergencyReport> emergencyReports;
    private List<FestivalDiscount> festivalDiscounts = new CopyOnWriteArrayList<>();

    // File paths for different data types
    private static final String TOURISTS_FILE = "data/tourists.txt";
    private static final String GUIDES_FILE = "data/guides.txt";
    private static final String ATTRACTIONS_FILE = "data/attractions.txt";
    private static final String BOOKINGS_FILE = "data/bookings.txt";
    private static final String EMERGENCY_REPORTS_FILE = "data/emergency_reports.txt";
    private static final String FESTIVAL_DISCOUNTS_FILE = "data/festival_discounts.txt";

    // Data change listeners for real-time updates
    private List<DataChangeListener> dataChangeListeners;

    private DataManager() {
        tourists = new ConcurrentHashMap<>();
        guides = new ConcurrentHashMap<>();
        attractions = new ConcurrentHashMap<>();
        bookings = new ConcurrentHashMap<>();
        emergencyReports = new CopyOnWriteArrayList<>();
        dataChangeListeners = new CopyOnWriteArrayList<>();

        // Create data directory if it doesn't exist
        createDataDirectory();
        initializeSampleData();
    }

    public static DataManager getInstance() {
        if (instance == null) {
            synchronized (DataManager.class) {
                if (instance == null) {
                    instance = new DataManager();
                }
            }
        }
        return instance;
    }

    private void createDataDirectory() {
        File dataDir = new File("data");
        if (!dataDir.exists()) {
            dataDir.mkdirs();
            System.out.println("Created data directory: " + dataDir.getAbsolutePath());
        }
    }

    private void initializeSampleData() {
        // Sample tourists
        tourists.put("T001", new Tourist("T001", "John Smith", "USA", "+1-555-0123", "+1-555-0124", "john", "password"));
        tourists.put("T002", new Tourist("T002", "Maria Garcia", "Spain", "+34-600-123456", "+34-600-123457", "maria", "password"));
        tourists.put("T003", new Tourist("T003", "Yuki Tanaka", "Japan", "+81-90-1234-5678", "+81-90-1234-5679", "yuki", "password"));

        // Sample guides
        guides.put("G001", new Guide("G001", "Ram Bahadur", Arrays.asList("English", "Nepali", "Hindi"), 5, "+977-9841234567", "ram", "password"));
        guides.put("G002", new Guide("G002", "Sita Sharma", Arrays.asList("English", "Nepali", "French"), 8, "+977-9851234567", "sita", "password"));
        guides.put("G003", new Guide("G003", "Pemba Sherpa", Arrays.asList("English", "Nepali", "Tibetan"), 12, "+977-9861234567", "pemba", "password"));

        // Sample attractions with price
        attractions.put("A001", new Attraction("A001", "Everest Base Camp", "Trek", "Solukhumbu", "Hard", 5000));
        attractions.put("A002", new Attraction("A002", "Pashupatinath Temple", "Heritage", "Kathmandu", "Easy", 1200));
        attractions.put("A003", new Attraction("A003", "Annapurna Circuit", "Trek", "Annapurna", "Medium", 3500));
        attractions.put("A004", new Attraction("A004", "Chitwan National Park", "Wildlife", "Chitwan", "Easy", 2000));
        attractions.put("A005", new Attraction("A005", "Pokhara Lake", "Adventure", "Pokhara", "Easy", 1500));
        attractions.put("A006", new Attraction("A006", "Lumbini", "Heritage", "Lumbini", "Easy", 1000));

        // Sample bookings
        bookings.put("B001", new Booking("B001", "T001", "G001", "A001", LocalDate.now().plusDays(30), "Confirmed"));
        bookings.put("B002", new Booking("B002", "T002", "G002", "A002", LocalDate.now().plusDays(15), "Pending"));
        bookings.put("B003", new Booking("B003", "T003", "G003", "A003", LocalDate.now().plusDays(45), "Confirmed"));

        // Sample festival discounts
        festivalDiscounts.add(new FestivalDiscount("FD001", "Dashain Discount", 20, LocalDate.parse("2023-10-15"), LocalDate.parse("2023-10-30"), "Special discount for Dashain festival"));
        festivalDiscounts.add(new FestivalDiscount("FD002", "Tihar Discount", 15, LocalDate.parse("2023-11-01"), LocalDate.parse("2023-11-05"), "Special discount for Tihar festival"));
    }

    // Data change listener interface
    public interface DataChangeListener {
        void onDataChanged(String dataType, String operation, Object data);
    }

    public void addDataChangeListener(DataChangeListener listener) {
        dataChangeListeners.add(listener);
    }

    public void removeDataChangeListener(DataChangeListener listener) {
        dataChangeListeners.remove(listener);
    }

    private void notifyDataChange(String dataType, String operation, Object data) {
        for (DataChangeListener listener : dataChangeListeners) {
            try {
                listener.onDataChanged(dataType, operation, data);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        // Auto-save after any data change
        saveDataToFile();
    }

    // File I/O operations
    public void saveDataToFile() {
        try {
            saveTouristsToFile();
            saveGuidesToFile();
            saveAttractionsToFile();
            saveBookingsToFile();
            saveEmergencyReportsToFile();
            saveFestivalDiscountsToFile();
            System.out.println("All data saved to files successfully at " + LocalDateTime.now());
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error saving data to files: " + e.getMessage());
        }
    }

    public void loadDataFromFile() {
        try {
            loadTouristsFromFile();
            loadGuidesFromFile();
            loadAttractionsFromFile();
            loadBookingsFromFile();
            loadEmergencyReportsFromFile();
            loadFestivalDiscountsFromFile();
            System.out.println("All data loaded from files successfully");
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error loading data from files: " + e.getMessage());
            // Keep sample data if file loading fails
        }
    }

    private void saveTouristsToFile() throws IOException {
        try (PrintWriter writer = new PrintWriter(new FileWriter(TOURISTS_FILE))) {
            writer.println("# Tourist Data - Format: ID|Name|Nationality|Contact|EmergencyContact|Username|Password");
            for (Tourist tourist : tourists.values()) {
                writer.println(String.format("%s|%s|%s|%s|%s|%s|%s",
                        tourist.getId(), tourist.getName(), tourist.getNationality(),
                        tourist.getContact(), tourist.getEmergencyContact(),
                        tourist.getUsername(), tourist.getPassword()));
            }
        }
    }

    private void loadTouristsFromFile() throws IOException {
        File file = new File(TOURISTS_FILE);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("#") || line.trim().isEmpty()) continue;

                String[] parts = line.split("\\|");
                if (parts.length >= 7) {
                    Tourist tourist = new Tourist(parts[0], parts[1], parts[2], parts[3], parts[4], parts[5], parts[6]);
                    tourists.put(tourist.getId(), tourist);
                }
            }
        }
    }

    private void saveGuidesToFile() throws IOException {
        try (PrintWriter writer = new PrintWriter(new FileWriter(GUIDES_FILE))) {
            writer.println("# Guide Data - Format: ID|Name|Languages|Experience|Contact|Username|Password");
            for (Guide guide : guides.values()) {
                writer.println(String.format("%s|%s|%s|%d|%s|%s|%s",
                        guide.getId(), guide.getName(), String.join(",", guide.getLanguages()),
                        guide.getExperience(), guide.getContact(),
                        guide.getUsername(), guide.getPassword()));
            }
        }
    }

    private void loadGuidesFromFile() throws IOException {
        File file = new File(GUIDES_FILE);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("#") || line.trim().isEmpty()) continue;

                String[] parts = line.split("\\|");
                if (parts.length >= 7) {
                    List<String> languages = Arrays.asList(parts[2].split(","));
                    int experience = Integer.parseInt(parts[3]);
                    Guide guide = new Guide(parts[0], parts[1], languages, experience, parts[4], parts[5], parts[6]);
                    guides.put(guide.getId(), guide);
                }
            }
        }
    }

    private void saveAttractionsToFile() throws IOException {
        try (PrintWriter writer = new PrintWriter(new FileWriter(ATTRACTIONS_FILE))) {
            writer.println("# Attraction Data - Format: ID|Name|Type|Location|Difficulty|Price");
            for (Attraction attraction : attractions.values()) {
                writer.println(String.format("%s|%s|%s|%s|%s|%.2f",
                        attraction.getId(), attraction.getName(), attraction.getType(),
                        attraction.getLocation(), attraction.getDifficulty(), attraction.getPrice()));
            }
        }
    }

    private void loadAttractionsFromFile() throws IOException {
        File file = new File(ATTRACTIONS_FILE);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("#") || line.trim().isEmpty()) continue;

                String[] parts = line.split("\\|");
                if (parts.length >= 6) {
                    double price = 0.0;
                    try {
                        price = Double.parseDouble(parts[5]);
                    } catch (NumberFormatException e) {
                        price = 0.0;
                    }
                    Attraction attraction = new Attraction(parts[0], parts[1], parts[2], parts[3], parts[4], price);
                    attractions.put(attraction.getId(), attraction);
                }
            }
        }
    }

    private void saveBookingsToFile() throws IOException {
        try (PrintWriter writer = new PrintWriter(new FileWriter(BOOKINGS_FILE))) {
            writer.println("# Booking Data - Format: ID|TouristID|GuideID|AttractionID|Date|Status");
            DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE;
            for (Booking booking : bookings.values()) {
                writer.println(String.format("%s|%s|%s|%s|%s|%s",
                        booking.getId(), booking.getTouristId(), booking.getGuideId(),
                        booking.getAttractionId(), booking.getDate().format(formatter), booking.getStatus()));
            }
        }
    }

    private void loadBookingsFromFile() throws IOException {
        File file = new File(BOOKINGS_FILE);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("#") || line.trim().isEmpty()) continue;

                String[] parts = line.split("\\|");
                if (parts.length >= 6) {
                    LocalDate date = LocalDate.parse(parts[4], formatter);
                    Booking booking = new Booking(parts[0], parts[1], parts[2], parts[3], date, parts[5]);
                    bookings.put(booking.getId(), booking);
                }
            }
        }
    }

    private void saveEmergencyReportsToFile() throws IOException {
        try (PrintWriter writer = new PrintWriter(new FileWriter(EMERGENCY_REPORTS_FILE))) {
            writer.println("# Emergency Report Data - Format: ID|BookingID|Description|Timestamp|ReportedBy");
            DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
            for (EmergencyReport report : emergencyReports) {
                writer.println(String.format("%s|%s|%s|%s|%s",
                        report.getId(), report.getBookingId(), report.getDescription().replace("|", "\\|"),
                        report.getTimestamp().format(formatter), report.getReportedBy()));
            }
        }
    }

    private void loadEmergencyReportsFromFile() throws IOException {
        File file = new File(EMERGENCY_REPORTS_FILE);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("#") || line.trim().isEmpty()) continue;

                String[] parts = line.split("\\|");
                if (parts.length >= 5) {
                    LocalDateTime timestamp = LocalDateTime.parse(parts[3], formatter);
                    String description = parts[2].replace("\\|", "|");
                    EmergencyReport report = new EmergencyReport(parts[0], parts[1], description, timestamp, parts[4]);
                    emergencyReports.add(report);
                }
            }
        }
    }

    private void saveFestivalDiscountsToFile() throws IOException {
        try (PrintWriter writer = new PrintWriter(new FileWriter(FESTIVAL_DISCOUNTS_FILE))) {
            writer.println("# FestivalDiscount Data - Format: ID|Name|Percentage|StartDate|EndDate|Description");
            for (FestivalDiscount d : festivalDiscounts) {
                writer.println(String.format("%s|%s|%.2f|%s|%s|%s",
                        d.getId(), d.getName(), d.getPercentage(),
                        d.getStartDate(), d.getEndDate(), d.getDescription()));
            }
        }
    }

    private void loadFestivalDiscountsFromFile() throws IOException {
        File file = new File(FESTIVAL_DISCOUNTS_FILE);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("#") || line.trim().isEmpty()) continue;

                String[] parts = line.split("\\|");
                if (parts.length >= 6) {
                    FestivalDiscount d = new FestivalDiscount(
                            parts[0], parts[1], Double.parseDouble(parts[2]),
                            LocalDate.parse(parts[3]), LocalDate.parse(parts[4]), parts[5]);
                    festivalDiscounts.add(d);
                }
            }
        }
    }

    // CRUD operations for tourists with real-time updates
    public void addTourist(Tourist tourist) {
        tourists.put(tourist.getId(), tourist);
        notifyDataChange("TOURIST", "ADD", tourist);
        System.out.println("Tourist added: " + tourist.getName());
    }

    public Tourist getTourist(String id) {
        return tourists.get(id);
    }

    public Map<String, Tourist> getAllTourists() {
        return new HashMap<>(tourists);
    }

    public void updateTourist(Tourist tourist) {
        tourists.put(tourist.getId(), tourist);
        notifyDataChange("TOURIST", "UPDATE", tourist);
        System.out.println("Tourist updated: " + tourist.getName());
    }

    public void deleteTourist(String id) {
        Tourist removed = tourists.remove(id);
        if (removed != null) {
            // Also remove related bookings
            bookings.entrySet().removeIf(entry -> entry.getValue().getTouristId().equals(id));
            notifyDataChange("TOURIST", "DELETE", removed);
            System.out.println("Tourist deleted: " + removed.getName());
        }
    }

    // CRUD operations for guides with real-time updates
    public void addGuide(Guide guide) {
        guides.put(guide.getId(), guide);
        notifyDataChange("GUIDE", "ADD", guide);
        System.out.println("Guide added: " + guide.getName());
    }

    public Guide getGuide(String id) {
        return guides.get(id);
    }

    public Map<String, Guide> getAllGuides() {
        return new HashMap<>(guides);
    }

    public void updateGuide(Guide guide) {
        guides.put(guide.getId(), guide);
        notifyDataChange("GUIDE", "UPDATE", guide);
        System.out.println("Guide updated: " + guide.getName());
    }

    public void deleteGuide(String id) {
        Guide removed = guides.remove(id);
        if (removed != null) {
            // Also remove related bookings
            bookings.entrySet().removeIf(entry -> entry.getValue().getGuideId().equals(id));
            notifyDataChange("GUIDE", "DELETE", removed);
            System.out.println("Guide deleted: " + removed.getName());
        }
    }

    // CRUD operations for attractions with real-time updates
    public void addAttraction(Attraction attraction) {
        attractions.put(attraction.getId(), attraction);
        notifyDataChange("ATTRACTION", "ADD", attraction);
        System.out.println("Attraction added: " + attraction.getName());
    }

    public Attraction getAttraction(String id) {
        return attractions.get(id);
    }

    public Map<String, Attraction> getAllAttractions() {
        return new HashMap<>(attractions);
    }

    public void updateAttraction(Attraction attraction) {
        attractions.put(attraction.getId(), attraction);
        notifyDataChange("ATTRACTION", "UPDATE", attraction);
        System.out.println("Attraction updated: " + attraction.getName());
    }

    public void deleteAttraction(String id) {
        Attraction removed = attractions.remove(id);
        if (removed != null) {
            // Also remove related bookings
            bookings.entrySet().removeIf(entry -> entry.getValue().getAttractionId().equals(id));
            notifyDataChange("ATTRACTION", "DELETE", removed);
            System.out.println("Attraction deleted: " + removed.getName());
        }
    }

    // CRUD operations for bookings with real-time updates
    public void addBooking(Booking booking) {
        bookings.put(booking.getId(), booking);
        notifyDataChange("BOOKING", "ADD", booking);
        System.out.println("Booking added: " + booking.getId());
    }

    public Booking getBooking(String id) {
        return bookings.get(id);
    }

    public Map<String, Booking> getAllBookings() {
        return new HashMap<>(bookings);
    }

    public void updateBooking(Booking booking) {
        bookings.put(booking.getId(), booking);
        notifyDataChange("BOOKING", "UPDATE", booking);
        System.out.println("Booking updated: " + booking.getId());
    }

    public void deleteBooking(String id) {
        Booking removed = bookings.remove(id);
        if (removed != null) {
            notifyDataChange("BOOKING", "DELETE", removed);
            System.out.println("Booking deleted: " + removed.getId());
        }
    }

    // Emergency reports with real-time updates
    public void addEmergencyReport(EmergencyReport report) {
        emergencyReports.add(report);
        notifyDataChange("EMERGENCY_REPORT", "ADD", report);
        System.out.println("Emergency report added: " + report.getId());
    }

    public List<EmergencyReport> getAllEmergencyReports() {
        return new ArrayList<>(emergencyReports);
    }

    public List<FestivalDiscount> getFestivalDiscounts() {
        return new ArrayList<>(festivalDiscounts);
    }

    public void addFestivalDiscount(FestivalDiscount discount) {
        festivalDiscounts.add(discount);
        notifyDataChange("FESTIVAL_DISCOUNT", "ADD", discount);
    }

    public void removeFestivalDiscount(String id) {
        festivalDiscounts.removeIf(d -> d.getId().equals(id));
        notifyDataChange("FESTIVAL_DISCOUNT", "REMOVE", id);
    }

    public FestivalDiscount getActiveDiscount() {
        LocalDate today = LocalDate.now();
        for (FestivalDiscount d : festivalDiscounts) {
            if (d.isActive(today)) return d;
        }
        return null;
    }

    public double getDiscountedPrice(double price) {
        FestivalDiscount discount = getActiveDiscount();
        if (discount != null) {
            return price * (1 - discount.getPercentage() / 100.0);
        }
        return price;
    }

    // Authentication methods
    public Tourist authenticateTourist(String username, String password) {
        return tourists.values().stream()
                .filter(t -> t.getUsername().equals(username) && t.getPassword().equals(password))
                .findFirst()
                .orElse(null);
    }

    public Guide authenticateGuide(String username, String password) {
        return guides.values().stream()
                .filter(g -> g.getUsername().equals(username) && g.getPassword().equals(password))
                .findFirst()
                .orElse(null);
    }

    public boolean authenticateAdmin(String username, String password) {
        return "admin".equals(username) && "admin".equals(password);
    }

    // Generate unique IDs
    public String generateTouristId() {
        return "T" + String.format("%03d", tourists.size() + 1);
    }

    public String generateGuideId() {
        return "G" + String.format("%03d", guides.size() + 1);
    }

    public String generateAttractionId() {
        return "A" + String.format("%03d", attractions.size() + 1);
    }

    public String generateBookingId() {
        return "B" + String.format("%03d", bookings.size() + 1);
    }

    public String generateEmergencyReportId() {
        return "E" + String.format("%03d", emergencyReports.size() + 1);
    }

    // Get bookings by tourist
    public List<Booking> getBookingsByTourist(String touristId) {
        return bookings.values().stream()
                .filter(booking -> booking.getTouristId().equals(touristId))
                .collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
    }

    // Get bookings by guide
    public List<Booking> getBookingsByGuide(String guideId) {
        return bookings.values().stream()
                .filter(booking -> booking.getGuideId().equals(guideId))
                .collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
    }

    public double getAttractionDisplayPrice(Attraction attraction) {
        return getDiscountedPrice(attraction.getPrice());
    }
}

