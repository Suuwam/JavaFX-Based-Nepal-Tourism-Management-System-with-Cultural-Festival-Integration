package com.nepal.tourism.controllers;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import com.nepal.tourism.models.*;
import com.nepal.tourism.utils.DataManager;
import com.nepal.tourism.utils.LanguageManager;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public class TouristController implements DataManager.DataChangeListener {
    private Stage primaryStage;
    private Tourist currentTourist;
    private LanguageManager langManager = LanguageManager.getInstance();
    private DataManager dataManager = DataManager.getInstance();
    
    // Observable lists for real-time updates
    private ObservableList<BookingDisplay> myBookingsList = FXCollections.observableArrayList();
    private ObservableList<Attraction> attractionsList = FXCollections.observableArrayList();
    
    public TouristController(Tourist tourist) {
        this.currentTourist = tourist;
    }
    
    public void showTouristDashboard(Stage stage) {
        this.primaryStage = stage;
        
        // Register for data change notifications
        dataManager.addDataChangeListener(this);
        
        BorderPane root = new BorderPane();
        root.getStyleClass().add("tourist-dashboard");
        
        // Top menu bar
        MenuBar menuBar = createMenuBar();
        root.setTop(menuBar);
        
        // Main content with tabs
        TabPane tabPane = new TabPane();
        tabPane.getTabs().addAll(
            createMyBookingsTab(),
            createCreateBookingTab(),
            createAttractionsTab(),
            createProfileTab() // Add profile tab
        );
        
        root.setCenter(tabPane);
        
        // Load initial data
        refreshMyBookings();
        refreshAttractions();
        
        Scene scene = new Scene(root, 1200, 800);
        scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());
        
        primaryStage.setTitle("Tours Nepal - Tourist Dashboard");
        primaryStage.setScene(scene);
        primaryStage.setOnCloseRequest(e -> {
            dataManager.removeDataChangeListener(this);
            dataManager.saveDataToFile();
        });
        primaryStage.show();
    }
    
    @Override
    public void onDataChanged(String dataType, String operation, Object data) {
        // Update UI on JavaFX Application Thread
        Platform.runLater(() -> {
            System.out.println("Tourist Dashboard: Data changed - " + dataType + " " + operation);
            if ("BOOKING".equals(dataType) || "ATTRACTION".equals(dataType) || 
                "GUIDE".equals(dataType) || "TOURIST".equals(dataType)) {
                refreshMyBookings();
                refreshAttractions();
            }
        });
    }
    
    private void refreshMyBookings() {
        myBookingsList.clear();
        List<Booking> bookings = dataManager.getBookingsByTourist(currentTourist.getId());
        
        for (Booking booking : bookings) {
            Guide guide = dataManager.getGuide(booking.getGuideId());
            Attraction attraction = dataManager.getAttraction(booking.getAttractionId());
            
            myBookingsList.add(new BookingDisplay(
                booking.getId(),
                currentTourist.getName(),
                guide != null ? guide.getName() : "Unknown",
                attraction != null ? attraction.getName() : "Unknown",
                booking.getDate(),
                booking.getStatus()
            ));
        }
    }
    
    private void refreshAttractions() {
        attractionsList.setAll(dataManager.getAllAttractions().values());
    }
    
    private MenuBar createMenuBar() {
        MenuBar menuBar = new MenuBar();
        
        Menu fileMenu = new Menu("File");
        MenuItem logoutItem = new MenuItem(langManager.getText("logout"));
        logoutItem.setOnAction(e -> {
            dataManager.removeDataChangeListener(this);
            dataManager.saveDataToFile();
            LoginController loginController = new LoginController();
            loginController.showLoginScreen(primaryStage);
        });
        fileMenu.getItems().add(logoutItem);
        
        Menu languageMenu = new Menu(langManager.getText("language"));
        MenuItem englishItem = new MenuItem("English");
        MenuItem nepaliItem = new MenuItem("नेपाली");
        
        englishItem.setOnAction(e -> {
            langManager.setLanguage("en");
            showTouristDashboard(primaryStage);
        });
        
        nepaliItem.setOnAction(e -> {
            langManager.setLanguage("ne");
            showTouristDashboard(primaryStage);
        });
        
        languageMenu.getItems().addAll(englishItem, nepaliItem);
        menuBar.getMenus().addAll(fileMenu, languageMenu);
        
        return menuBar;
    }
    
    private Tab createProfileTab() {
        Tab tab = new Tab("My Profile");
        tab.setClosable(false);
        VBox content = new VBox(15);
        content.setPadding(new Insets(20));
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        TextField nameField = new TextField(currentTourist.getName());
        TextField nationalityField = new TextField(currentTourist.getNationality());
        TextField contactField = new TextField(currentTourist.getContact());
        TextField emergencyContactField = new TextField(currentTourist.getEmergencyContact());
        TextField usernameField = new TextField(currentTourist.getUsername());
        PasswordField passwordField = new PasswordField();
        passwordField.setText(currentTourist.getPassword());
        grid.add(new Label("Name:"), 0, 0);
        grid.add(nameField, 1, 0);
        grid.add(new Label("Nationality:"), 0, 1);
        grid.add(nationalityField, 1, 1);
        grid.add(new Label("Contact:"), 0, 2);
        grid.add(contactField, 1, 2);
        grid.add(new Label("Emergency Contact:"), 0, 3);
        grid.add(emergencyContactField, 1, 3);
        grid.add(new Label("Username:"), 0, 4);
        grid.add(usernameField, 1, 4);
        grid.add(new Label("Password:"), 0, 5);
        grid.add(passwordField, 1, 5);
        Button saveButton = new Button("Save Changes");
        saveButton.setOnAction(e -> {
            if (nameField.getText().trim().isEmpty() || nationalityField.getText().trim().isEmpty() ||
                contactField.getText().trim().isEmpty() || emergencyContactField.getText().trim().isEmpty() ||
                usernameField.getText().trim().isEmpty() || passwordField.getText().trim().isEmpty()) {
                showAlert(Alert.AlertType.ERROR, "Error", "Please fill in all fields.");
                return;
            }
            currentTourist.setName(nameField.getText());
            currentTourist.setNationality(nationalityField.getText());
            currentTourist.setContact(contactField.getText());
            currentTourist.setEmergencyContact(emergencyContactField.getText());
            currentTourist.setUsername(usernameField.getText());
            currentTourist.setPassword(passwordField.getText());
            dataManager.updateTourist(currentTourist);
            showAlert(Alert.AlertType.INFORMATION, "Success", "Profile updated successfully!");
        });
        Button logoutButton = new Button("Logout");
        logoutButton.setOnAction(e -> {
            dataManager.removeDataChangeListener(this);
            dataManager.saveDataToFile();
            LoginController loginController = new LoginController();
            loginController.showLoginScreen(primaryStage);
        });
        HBox buttonBox = new HBox(10, saveButton, logoutButton);
        content.getChildren().addAll(grid, buttonBox);
        tab.setContent(content);
        return tab;
    }

    private Tab createMyBookingsTab() {
        Tab tab = new Tab(langManager.getText("my_bookings"));
        tab.setClosable(false);
        
        VBox content = new VBox(10);
        content.setPadding(new Insets(20));
        
        // Buttons
        HBox buttonBox = new HBox(10);
        Button deleteButton = new Button(langManager.getText("delete"));
        Button emergencyButton = new Button(langManager.getText("report_emergency"));
        
        deleteButton.getStyleClass().add("danger-button");
        emergencyButton.getStyleClass().add("warning-button");
        
        buttonBox.getChildren().addAll(deleteButton, emergencyButton);
        
        // Table
        TableView<BookingDisplay> table = new TableView<>();
        table.setItems(myBookingsList);
        table.getColumns().addAll(
            createTableColumn("ID", "id"),
            createTableColumn("Guide", "guideName"),
            createTableColumn("Attraction", "attractionName"),
            createTableColumn(langManager.getText("date"), "date"),
            createTableColumn(langManager.getText("status"), "status")
        );
        
        // Button actions
        deleteButton.setOnAction(e -> {
            BookingDisplay selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
                confirmation.setTitle("Confirm Deletion");
                confirmation.setHeaderText("Delete Booking");
                confirmation.setContentText("Are you sure you want to delete this booking?");
                
                if (confirmation.showAndWait().get() == ButtonType.OK) {
                    dataManager.deleteBooking(selected.getId());
                    showAlert(Alert.AlertType.INFORMATION, "Success", "Booking deleted successfully!");
                }
            } else {
                showAlert(Alert.AlertType.WARNING, "Warning", "Please select a booking to delete.");
            }
        });
        
        emergencyButton.setOnAction(e -> {
            BookingDisplay selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                showEmergencyReportDialog(selected.getId());
            } else {
                showAlert(Alert.AlertType.WARNING, "Warning", "Please select a booking to report emergency.");
            }
        });
        
        content.getChildren().addAll(buttonBox, table);

        Button logoutButton = new Button("Logout");
        logoutButton.setOnAction(e -> {
            dataManager.removeDataChangeListener(this);
            dataManager.saveDataToFile();
            LoginController loginController = new LoginController();
            loginController.showLoginScreen(primaryStage);
        });
        content.getChildren().add(logoutButton);
        tab.setContent(content);
        
        return tab;
    }
    
    private Tab createCreateBookingTab() {
        Tab tab = new Tab(langManager.getText("create_booking"));
        tab.setClosable(false);
        
        VBox content = new VBox(20);
        content.setPadding(new Insets(20));
        
        GridPane form = new GridPane();
        form.setHgap(10);
        form.setVgap(10);
        
        ComboBox<Guide> guideCombo = new ComboBox<>();
        guideCombo.getItems().addAll(dataManager.getAllGuides().values());
        guideCombo.setPromptText("Select Guide");
        
        ComboBox<Attraction> attractionCombo = new ComboBox<>();
        attractionCombo.getItems().addAll(dataManager.getAllAttractions().values());
        attractionCombo.setPromptText("Select Attraction");
        
        DatePicker datePicker = new DatePicker();
        datePicker.setValue(LocalDate.now().plusDays(1));
        
        ComboBox<String> statusCombo = new ComboBox<>();
        statusCombo.getItems().addAll("Pending", "Confirmed", "Cancelled");
        statusCombo.setValue("Pending");
        
        form.add(new Label("Guide:"), 0, 0);
        form.add(guideCombo, 1, 0);
        form.add(new Label("Attraction:"), 0, 1);
        form.add(attractionCombo, 1, 1);
        form.add(new Label(langManager.getText("date") + ":"), 0, 2);
        form.add(datePicker, 1, 2);
        form.add(new Label(langManager.getText("status") + ":"), 0, 3);
        form.add(statusCombo, 1, 3);
        
        Button createButton = new Button(langManager.getText("create_booking"));
        createButton.getStyleClass().add("primary-button");
        createButton.setOnAction(e -> {
            if (guideCombo.getValue() != null && attractionCombo.getValue() != null && datePicker.getValue() != null) {
                Booking newBooking = new Booking(
                    dataManager.generateBookingId(),
                    currentTourist.getId(),
                    guideCombo.getValue().getId(),
                    attractionCombo.getValue().getId(),
                    datePicker.getValue(),
                    statusCombo.getValue()
                );
                dataManager.addBooking(newBooking);
                
                showAlert(Alert.AlertType.INFORMATION, "Success", "Your booking has been created successfully!");
                
                // Clear form
                guideCombo.setValue(null);
                attractionCombo.setValue(null);
                datePicker.setValue(LocalDate.now().plusDays(1));
                statusCombo.setValue("Pending");
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Please select both a guide and an attraction.");
            }
        });
        
        form.add(createButton, 1, 4);
        
        content.getChildren().add(form);

        Button logoutButton = new Button("Logout");
        logoutButton.setOnAction(e -> {
            dataManager.removeDataChangeListener(this);
            dataManager.saveDataToFile();
            LoginController loginController = new LoginController();
            loginController.showLoginScreen(primaryStage);
        });
        content.getChildren().add(logoutButton);
        tab.setContent(content);
        
        return tab;
    }
    
    private Tab createAttractionsTab() {
        Tab tab = new Tab(langManager.getText("attractions"));
        tab.setClosable(false);
        
        VBox content = new VBox(10);
        content.setPadding(new Insets(20));
        
        Label discountLabel = new Label();
        FestivalDiscount activeDiscount = dataManager.getActiveDiscount();
        if (activeDiscount != null) {
            discountLabel.setText("Festival Discount: " + activeDiscount.getName() + " - " + activeDiscount.getPercentage() + "% off! (" + activeDiscount.getDescription() + ")");
            discountLabel.setStyle("-fx-text-fill: green; -fx-font-weight: bold;");
            content.getChildren().add(discountLabel);
        }
        // Table
        TableView<Attraction> table = new TableView<>();
        table.setItems(attractionsList);
        table.getColumns().addAll(
            createTableColumn(langManager.getText("name"), "name"),
            createTableColumn(langManager.getText("type"), "type"),
            createTableColumn(langManager.getText("location"), "location"),
            createTableColumn(langManager.getText("difficulty"), "difficulty"),
            new TableColumn<Attraction, String>("Price") {{
                setCellValueFactory(cellData -> {
                    Attraction a = cellData.getValue();
                    double original = a.getPrice();
                    double discounted = dataManager.getAttractionDisplayPrice(a);
                    String priceText = discounted < original ? String.format("%.2f (was %.2f)", discounted, original) : String.format("%.2f", original);
                    return new javafx.beans.property.SimpleStringProperty(priceText);
                });
                setPrefWidth(150);
            }}
        );
        
        content.getChildren().add(table);

        Button logoutButton = new Button("Logout");
        logoutButton.setOnAction(e -> {
            dataManager.removeDataChangeListener(this);
            dataManager.saveDataToFile();
            LoginController loginController = new LoginController();
            loginController.showLoginScreen(primaryStage);
        });
        content.getChildren().add(logoutButton);
        tab.setContent(content);
        
        return tab;
    }
    
    private void showEmergencyReportDialog(String bookingId) {
        Stage dialog = new Stage();
        dialog.setTitle(langManager.getText("report_emergency"));
        
        VBox content = new VBox(10);
        content.setPadding(new Insets(20));
        
        Label titleLabel = new Label("Emergency Report for Booking: " + bookingId);
        titleLabel.getStyleClass().add("section-title");
        
        TextArea descriptionArea = new TextArea();
        descriptionArea.setPromptText("Describe the emergency situation...");
        descriptionArea.setPrefRowCount(5);
        
        HBox buttonBox = new HBox(10);
        Button submitButton = new Button("Submit Report");
        Button cancelButton = new Button(langManager.getText("cancel"));
        
        submitButton.getStyleClass().add("danger-button");
        
        submitButton.setOnAction(e -> {
            if (!descriptionArea.getText().trim().isEmpty()) {
                EmergencyReport report = new EmergencyReport(
                    dataManager.generateEmergencyReportId(),
                    bookingId,
                    descriptionArea.getText(),
                    LocalDateTime.now(),
                    currentTourist.getName()
                );
                dataManager.addEmergencyReport(report);
                
                showAlert(Alert.AlertType.INFORMATION, "Emergency Reported", 
                         "Your emergency report has been submitted successfully. " +
                         "Authorities will be notified immediately.\n\n" +
                         "Report ID: " + report.getId() + "\n" +
                         "Timestamp: " + report.getTimestamp());
                
                dialog.close();
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Please provide a description of the emergency.");
            }
        });
        
        cancelButton.setOnAction(e -> dialog.close());
        
        buttonBox.getChildren().addAll(submitButton, cancelButton);
        
        content.getChildren().addAll(titleLabel, new Label("Description:"), descriptionArea, buttonBox);
        
        Scene scene = new Scene(content, 1200, 800);
        scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());
        dialog.setScene(scene);
        dialog.showAndWait();
    }
    
    private <T> TableColumn<T, String> createTableColumn(String title, String property) {
        TableColumn<T, String> column = new TableColumn<>(title);
        column.setCellValueFactory(new PropertyValueFactory<>(property));
        column.setPrefWidth(150);
        return column;
    }
    
    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    
    // Helper class for booking display
    public static class BookingDisplay {
        private String id;
        private String touristName;
        private String guideName;
        private String attractionName;
        private LocalDate date;
        private String status;
        
        public BookingDisplay(String id, String touristName, String guideName, 
                            String attractionName, LocalDate date, String status) {
            this.id = id;
            this.touristName = touristName;
            this.guideName = guideName;
            this.attractionName = attractionName;
            this.date = date;
            this.status = status;
        }
        
        // Getters
        public String getId() { return id; }
        public String getTouristName() { return touristName; }
        public String getGuideName() { return guideName; }
        public String getAttractionName() { return attractionName; }
        public LocalDate getDate() { return date; }
        public String getStatus() { return status; }
    }
}
