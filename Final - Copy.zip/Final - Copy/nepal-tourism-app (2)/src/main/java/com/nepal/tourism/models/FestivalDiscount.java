package com.nepal.tourism.models;

import java.io.Serializable;
import java.time.LocalDate;

public class FestivalDiscount implements Serializable {
    private String id;
    private String name;
    private double percentage;
    private LocalDate startDate;
    private LocalDate endDate;
    private String description;

    public FestivalDiscount() {}

    public FestivalDiscount(String id, String name, double percentage, LocalDate startDate, LocalDate endDate, String description) {
        this.id = id;
        this.name = name;
        this.percentage = percentage;
        this.startDate = startDate;
        this.endDate = endDate;
        this.description = description;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public double getPercentage() { return percentage; }
    public LocalDate getStartDate() { return startDate; }
    public LocalDate getEndDate() { return endDate; }
    public String getDescription() { return description; }

    public boolean isActive(LocalDate date) {
        return (date.isEqual(startDate) || date.isAfter(startDate)) && (date.isEqual(endDate) || date.isBefore(endDate));
    }
}

