package com.nepal.tourism;

import javafx.application.Application;
import javafx.stage.Stage;
import com.nepal.tourism.controllers.LoginController;
import com.nepal.tourism.utils.DataManager;
import com.nepal.tourism.utils.LanguageManager;

public class TourismApp extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        try {
            // Initialize data and language managers
            DataManager.getInstance().loadDataFromFile();
            LanguageManager.getInstance().setLanguage("en");
            
            // Start with login screen
            LoginController loginController = new LoginController();
            loginController.showLoginScreen(primaryStage);
            
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error starting application: " + e.getMessage());
        }
    }
    
    @Override
    public void stop() {
        try {
            DataManager.getInstance().saveDataToFile();
            System.out.println("Data saved successfully on application exit.");
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error saving data on exit: " + e.getMessage());
        }
    }
    
    public static void main(String[] args) {
        Application.launch(TourismApp.class, args);
    }
}
