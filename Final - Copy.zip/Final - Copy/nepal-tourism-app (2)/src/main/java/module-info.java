module nepal.tourism {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;
    
    exports com.nepal.tourism;
    exports com.nepal.tourism.controllers;
    exports com.nepal.tourism.models;
    exports com.nepal.tourism.utils;
}
